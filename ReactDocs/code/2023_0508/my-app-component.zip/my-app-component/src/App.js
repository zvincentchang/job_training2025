
import withOpen from './hocs/withOpen'; // 邏輯
import Promotion from './Promotion';    // 畫面
import CreditCards from './CreditCards';// 畫面

// 1.相同邏輯元件套用在不同畫面主件(邏輯元件共用畫面不同)
// 上層主件:withOpen、下層主件:Promotion、CreditCards
const PromotionWithOpen = withOpen(Promotion);
const CreditCardsWithOpen = withOpen(CreditCards);

const App = ()  => (
    <div>
        <PromotionWithOpen/>
        <CreditCardsWithOpen/>
    </div>
);

export default App;