import fetch from 'cross-fetch';
import { Car } from './Car';

// ------------------------基本類型------------------------
// 能檢查值型別是否符合
let cusName: string = "Hello Two";
// text = "Hello Two";
let num1: number = 123;
let boo1: boolean = true;
let anyValue1: any = true;

// console.log(text);
console.log('let num1:', num1);
console.log('let boo1:', boo1);
console.log('let anyValue1:', anyValue1);

// ------------------------陣列------------------------
let strArr1: string[] = ['a', 'b', 'c'];
let strArr2: string[][] = [['a', 'b', 'c'], ['d', 'e', 'f']];
// 元組
let tuple1: [number, string, boolean] = [1, 'a', true];
let tuple2: [number, string][] = [[1, 'a'], [2, 'b']];

// ------------------------ Enum 枚舉 ------------------------
enum FoodNames {
    PORK = '豬肉',
    BEEF = '牛肉',
    FISH = '魚肉',
    CHICKEN = '雞肉'
};
const chicken = FoodNames.CHICKEN;
console.log('enum FoodNames:', chicken);

// ------------------------ Union ------------------------
let unionV1: number | string;
unionV1 = 1000;
unionV1 = 'str';

// ------------------------ type ------------------------
// 自訂義型別
type cusType = number | string;
let typeValue: cusType;

typeValue = 123;
typeValue = 'ABC';
console.log('let typeValue:', typeValue);

// ------------------------ interface ------------------------
interface UserInterface {
    name: string;
    age: number;
};
// 擴展UserInterface欄位
interface UserInterface {
    sex?: string // 問號代表可選擇欄位
};

// ------------------------ object from type、interface ------------------------
type userType = {
    name: string
    age?: number
};

// typ、interface差別：typ欄位不能擴充、interface欄位可以擴充
// 透過typ來規範物件應該要有哪些欄位
const userOne: userType = {
    name: 'YuShangLee',
    age: 36
};

const userTwo: UserInterface = {
    name: 'YuShangLee',
    age: 36,
    sex: 'Man'
};


// ------------------------ function ------------------------
// function 可透過宣告指定參數型態來規範傳入的參數值,以及規範function所回傳值的型態
function hello(a: number, b: number): number {
    return a + b;
}
console.log('function hello:', hello(1, 1));

// undefined 問號參數類型
// 可選擇性傳入的參數類型
// 必須放在參數列上的最後一個
function helloTwo(a: number, b: number, c?: number): number {
    // 透過判斷undefined就可讓 return a + b + c; 通過檢查編譯
    if (c === undefined) return -1;
    return a + b + c;
}

console.log('function helloTwo:', helloTwo(1, 2));
console.log('function helloTwo:', helloTwo(1, 2, 3));

// 箭頭函式
const func = (a: string): number => {
    let b = parseInt(a);
    b += 2;
    return b;
}

console.log('箭頭函式 const func:', func('3'));

// 箭頭函式省略{}接續直接代表回傳
const funcTwo = (a: string): number => parseInt(a) + 2;
console.log('箭頭函式 const funcTwo:', funcTwo('3'));

// ------------------------ as 斷言、fetch api ------------------------
type userData = {
    userId: number,
    id: number,
    title: string,
    completed: boolean
}

const axiosCourseData = async () => {
    const res = await fetch('https://jsonplaceholder.typicode.com/todos/1');
    // 透過as訂義fetch api所回傳的資料結構type
    const user = await res.json() as userData;
    console.log("fetch userId:", user.userId);
    console.log("fetch title:", user.title);
    console.log("fetch completed:", user.completed);
}

// axiosCourseData();

// ------------------------ class ------------------------

class Employee {

    // 公開(內外部皆可存取)
    public empNo: number;
    // 受保護(僅內部透過繼承關係存取)
    protected empName: string;
    // 私有(僅class內部)
    private empJobTitle: string;

    constructor(empNo: number, empName: string, empJobTitle: string) {
        this.empNo = empNo;
        this.empName = empName;
        this.empJobTitle = empJobTitle;
    }
}

const empOne = new Employee(7, 'Mark', 'Manager');
// 外部只能存取的到公開的成員
console.log("empOne.empNo:", empOne.empNo);
// console.log("empOne.empName:", empOne.empName);
// console.log("empOne.empJobTitle:", empOne.empJobTitle);

class SubEmployee extends Employee {

    private salary: number;

    constructor(empNo: number, empName: string, empJobTitle: string, salary: number) {
        super(empNo, empName, empJobTitle);
        this.salary = salary;
    }

    showEmp() {
        console.log("SubEmployee super.empNo:", this.empNo);
        console.log("SubEmployee super.empName:", this.empName);
        // console.log("SubEmployee super.empJobTitle:", this.empJobTitle);
    }

    addSalary(money: number): number {
        return this.salary + money;
    }
}

const empTwo = new SubEmployee(8, 'Wendy', 'Accounting', 35000);
empTwo.showEmp();
const newSalary = empTwo.addSalary(3000);
console.log("SubEmployee.addSalary:", newSalary);

// ------------------------ interface ------------------------

// 透過interface規範必須要有的欄位及方法
class CarImpl implements Car {
    name: string;
    age: number;
    constructor(name: string, age: number) {
        this.name = name;
        this.age = age;
    }
    driving(mph: number): string {
        return "mph:" + mph;
    }
}

const car = new CarImpl('TOYOTA', 15);
console.log("InterfaceCar.name:", car.name);
console.log("InterfaceCar.age:", car.age);
console.log("InterfaceCar.driving:", car.driving(60));

// ------------------------ 泛型 Generics ------------------------
// 運用泛型可彈性的在使用函數、類別時才宣告實際使用的型別
function print<T>(data: T) {
    console.log('data:', data);
}
print<string>('Hello');
print<number>(123);
print<boolean>(true);

interface Generics<T, R> {
    driving: (arg: T) => R;
}

class GenericsImpl implements Generics<number, string> {
    driving(arg: number): string {
        return "mph:" + arg;
    }
}

const generics = new GenericsImpl();
console.log('interface Generics:', generics.driving(60));

// ------------------------ utility(工具) ------------------------
// Typescript內建
// https://www.typescriptlang.org/docs/handbook/utility-types.html

// 1.Record<Keys, Type> 紀錄
// 相當於JAVA Map
interface CatInfo {
    age: number;
    breed: string;
}


const cats: Record<string, CatInfo> = {
    'miffy': { age: 10, breed: "Persian" },
    'boris': { age: 5, breed: "Maine Coon" },
    'mordred': { age: 16, breed: "British Shorthair" },
};

console.log(cats);

// 2.Pick<Type, Keys>挑選
// 透過Pick可從interface挑選"需要'的欄位設置給新宣告的Type,就可省略程式碼欄位宣告
interface Todo {
    title: string;
    description: string;
    completed: boolean;
}

type TodoPreview = Pick<Todo, "title" | "completed">;

const todo: TodoPreview = {
    title: "Clean room",
    completed: false,
};

console.log(todo);

// 3.Omit<Type, Keys>忽略
// 透過Omit可從interface忽略"不需要"的欄位設置給新宣告的Type,就可省略程式碼欄位宣告
interface TodoTwo {
    title: string;
    description: string;
    completed: boolean;
    createdAt: number;
}

type TodoPreviewTwo = Omit<TodoTwo, "description">;

const todoTwo: TodoPreviewTwo = {
    title: "Clean room",
    completed: false,
    createdAt: 1615544252770,
};

console.log(todoTwo);
