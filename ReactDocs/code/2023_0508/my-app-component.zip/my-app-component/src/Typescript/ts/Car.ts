export interface Car {
    name: string;
    age: number;
    driving: (mph: number) => string;
}