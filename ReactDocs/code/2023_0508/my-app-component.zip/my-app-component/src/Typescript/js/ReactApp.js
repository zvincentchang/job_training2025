"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const App = () => {
    return Hello;
    React;
    Typescript < /div>;
};
;
exports.default = App;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiUmVhY3RBcHAuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi90cy9SZWFjdEFwcC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLE1BQU0sR0FBRyxHQUFhLEdBQUcsRUFBRTtJQUN2QixPQUNTLEtBQUssQ0FBQTtJQUFDLEtBQUssQ0FBQTtJQUFDLFVBQVUsR0FBQyxLQUFLLENBQUE7QUFDckMsQ0FBQyxBQURvQyxDQUFBO0FBQ3BDLENBQUM7QUFHTixrQkFBZSxHQUFHLENBQUMifQ==