"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const cross_fetch_1 = __importDefault(require("cross-fetch"));
// ------------------------基本類型------------------------
// 能檢查值型別是否符合
let cusName = "Hello Two";
// text = "Hello Two";
let num1 = 123;
let boo1 = true;
let anyValue1 = true;
// console.log(text);
console.log('let num1:', num1);
console.log('let boo1:', boo1);
console.log('let anyValue1:', anyValue1);
// ------------------------陣列------------------------
let strArr1 = ['a', 'b', 'c'];
let strArr2 = [['a', 'b', 'c'], ['d', 'e', 'f']];
// 元組
let tuple1 = [1, 'a', true];
let tuple2 = [[1, 'a'], [2, 'b']];
// ------------------------ Enum 枚舉 ------------------------
var FoodNames;
(function (FoodNames) {
    FoodNames["PORK"] = "\u8C6C\u8089";
    FoodNames["BEEF"] = "\u725B\u8089";
    FoodNames["FISH"] = "\u9B5A\u8089";
    FoodNames["CHICKEN"] = "\u96DE\u8089";
})(FoodNames || (FoodNames = {}));
;
const chicken = FoodNames.CHICKEN;
console.log('enum FoodNames:', chicken);
// ------------------------ Union ------------------------
let unionV1;
unionV1 = 1000;
unionV1 = 'str';
let typeValue;
typeValue = 123;
typeValue = 'ABC';
console.log('let typeValue:', typeValue);
;
;
// typ、interface差別：typ欄位不能擴充、interface欄位可以擴充
// 透過typ來規範物件應該要有哪些欄位
const userOne = {
    name: 'YuShangLee',
    age: 36
};
const userTwo = {
    name: 'YuShangLee',
    age: 36,
    sex: 'Man'
};
// ------------------------ function ------------------------
// function 可透過宣告指定參數型態來規範傳入的參數值,以及規範function所回傳值的型態
function hello(a, b) {
    return a + b;
}
console.log('function hello:', hello(1, 1));
// undefined 問號參數類型
// 可選擇性傳入的參數類型
// 必須放在參數列上的最後一個
function helloTwo(a, b, c) {
    // 透過判斷undefined就可讓 return a + b + c; 通過檢查編譯
    if (c === undefined)
        return -1;
    return a + b + c;
}
console.log('function helloTwo:', helloTwo(1, 2));
console.log('function helloTwo:', helloTwo(1, 2, 3));
// 箭頭函式
const func = (a) => {
    let b = parseInt(a);
    b += 2;
    return b;
};
console.log('箭頭函式 const func:', func('3'));
// 箭頭函式省略{}接續直接代表回傳
const funcTwo = (a) => parseInt(a) + 2;
console.log('箭頭函式 const funcTwo:', funcTwo('3'));
const axiosCourseData = () => __awaiter(void 0, void 0, void 0, function* () {
    const res = yield (0, cross_fetch_1.default)('https://jsonplaceholder.typicode.com/todos/1');
    // 透過as訂義fetch api所回傳的資料結構type
    const user = yield res.json();
    console.log("fetch userId:", user.userId);
    console.log("fetch title:", user.title);
    console.log("fetch completed:", user.completed);
});
// axiosCourseData();
// ------------------------ class ------------------------
class Employee {
    constructor(empNo, empName, empJobTitle) {
        this.empNo = empNo;
        this.empName = empName;
        this.empJobTitle = empJobTitle;
    }
}
const empOne = new Employee(7, 'Mark', 'Manager');
// 外部只能存取的到公開的成員
console.log("empOne.empNo:", empOne.empNo);
// console.log("empOne.empName:", empOne.empName);
// console.log("empOne.empJobTitle:", empOne.empJobTitle);
class SubEmployee extends Employee {
    constructor(empNo, empName, empJobTitle, salary) {
        super(empNo, empName, empJobTitle);
        this.salary = salary;
    }
    showEmp() {
        console.log("SubEmployee super.empNo:", this.empNo);
        console.log("SubEmployee super.empName:", this.empName);
        // console.log("SubEmployee super.empJobTitle:", this.empJobTitle);
    }
    addSalary(money) {
        return this.salary + money;
    }
}
const empTwo = new SubEmployee(8, 'Wendy', 'Accounting', 35000);
empTwo.showEmp();
const newSalary = empTwo.addSalary(3000);
console.log("SubEmployee.addSalary:", newSalary);
// ------------------------ interface ------------------------
// 透過interface規範必須要有的欄位及方法
class CarImpl {
    constructor(name, age) {
        this.name = name;
        this.age = age;
    }
    driving(mph) {
        return "mph:" + mph;
    }
}
const car = new CarImpl('TOYOTA', 15);
console.log("InterfaceCar.name:", car.name);
console.log("InterfaceCar.age:", car.age);
console.log("InterfaceCar.driving:", car.driving(60));
// ------------------------ 泛型 Generics ------------------------
// 運用泛型可彈性的在使用函數、類別時才宣告實際使用的型別
function print(data) {
    console.log('data:', data);
}
print('Hello');
print(123);
print(true);
class GenericsImpl {
    driving(arg) {
        return "mph:" + arg;
    }
}
const generics = new GenericsImpl();
console.log('interface Generics:', generics.driving(60));
const cats = {
    'miffy': { age: 10, breed: "Persian" },
    'boris': { age: 5, breed: "Maine Coon" },
    'mordred': { age: 16, breed: "British Shorthair" },
};
console.log(cats);
const todo = {
    title: "Clean room",
    completed: false,
};
console.log(todo);
const todoTwo = {
    title: "Clean room",
    completed: false,
    createdAt: 1615544252770,
};
console.log(todoTwo);
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi90cy9pbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7OztBQUFBLDhEQUFnQztBQUdoQyx1REFBdUQ7QUFDdkQsYUFBYTtBQUNiLElBQUksT0FBTyxHQUFXLFdBQVcsQ0FBQztBQUNsQyxzQkFBc0I7QUFDdEIsSUFBSSxJQUFJLEdBQVcsR0FBRyxDQUFDO0FBQ3ZCLElBQUksSUFBSSxHQUFZLElBQUksQ0FBQztBQUN6QixJQUFJLFNBQVMsR0FBUSxJQUFJLENBQUM7QUFFMUIscUJBQXFCO0FBQ3JCLE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxDQUFDO0FBQy9CLE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxDQUFDO0FBQy9CLE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLEVBQUUsU0FBUyxDQUFDLENBQUM7QUFFekMscURBQXFEO0FBQ3JELElBQUksT0FBTyxHQUFhLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQztBQUN4QyxJQUFJLE9BQU8sR0FBZSxDQUFDLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQztBQUM3RCxLQUFLO0FBQ0wsSUFBSSxNQUFNLEdBQThCLENBQUMsQ0FBQyxFQUFFLEdBQUcsRUFBRSxJQUFJLENBQUMsQ0FBQztBQUN2RCxJQUFJLE1BQU0sR0FBdUIsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDO0FBRXRELDREQUE0RDtBQUM1RCxJQUFLLFNBS0o7QUFMRCxXQUFLLFNBQVM7SUFDVixrQ0FBVyxDQUFBO0lBQ1gsa0NBQVcsQ0FBQTtJQUNYLGtDQUFXLENBQUE7SUFDWCxxQ0FBYyxDQUFBO0FBQ2xCLENBQUMsRUFMSSxTQUFTLEtBQVQsU0FBUyxRQUtiO0FBQUEsQ0FBQztBQUNGLE1BQU0sT0FBTyxHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUM7QUFDbEMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsRUFBRSxPQUFPLENBQUMsQ0FBQztBQUV4QywwREFBMEQ7QUFDMUQsSUFBSSxPQUF3QixDQUFDO0FBQzdCLE9BQU8sR0FBRyxJQUFJLENBQUM7QUFDZixPQUFPLEdBQUcsS0FBSyxDQUFDO0FBS2hCLElBQUksU0FBa0IsQ0FBQztBQUV2QixTQUFTLEdBQUcsR0FBRyxDQUFDO0FBQ2hCLFNBQVMsR0FBRyxLQUFLLENBQUM7QUFDbEIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsRUFBRSxTQUFTLENBQUMsQ0FBQztBQU14QyxDQUFDO0FBSUQsQ0FBQztBQVFGLDRDQUE0QztBQUM1QyxxQkFBcUI7QUFDckIsTUFBTSxPQUFPLEdBQWE7SUFDdEIsSUFBSSxFQUFFLFlBQVk7SUFDbEIsR0FBRyxFQUFFLEVBQUU7Q0FDVixDQUFDO0FBRUYsTUFBTSxPQUFPLEdBQWtCO0lBQzNCLElBQUksRUFBRSxZQUFZO0lBQ2xCLEdBQUcsRUFBRSxFQUFFO0lBQ1AsR0FBRyxFQUFFLEtBQUs7Q0FDYixDQUFDO0FBR0YsNkRBQTZEO0FBQzdELG9EQUFvRDtBQUNwRCxTQUFTLEtBQUssQ0FBQyxDQUFTLEVBQUUsQ0FBUztJQUMvQixPQUFPLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDakIsQ0FBQztBQUNELE9BQU8sQ0FBQyxHQUFHLENBQUMsaUJBQWlCLEVBQUUsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBRTVDLG1CQUFtQjtBQUNuQixjQUFjO0FBQ2QsZ0JBQWdCO0FBQ2hCLFNBQVMsUUFBUSxDQUFDLENBQVMsRUFBRSxDQUFTLEVBQUUsQ0FBVTtJQUM5Qyw0Q0FBNEM7SUFDNUMsSUFBSSxDQUFDLEtBQUssU0FBUztRQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUM7SUFDL0IsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNyQixDQUFDO0FBRUQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsRUFBRSxRQUFRLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsRUFBRSxRQUFRLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBRXJELE9BQU87QUFDUCxNQUFNLElBQUksR0FBRyxDQUFDLENBQVMsRUFBVSxFQUFFO0lBQy9CLElBQUksQ0FBQyxHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUNwQixDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ1AsT0FBTyxDQUFDLENBQUM7QUFDYixDQUFDLENBQUE7QUFFRCxPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO0FBRTNDLG1CQUFtQjtBQUNuQixNQUFNLE9BQU8sR0FBRyxDQUFDLENBQVMsRUFBVSxFQUFFLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUN2RCxPQUFPLENBQUMsR0FBRyxDQUFDLHFCQUFxQixFQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO0FBVWpELE1BQU0sZUFBZSxHQUFHLEdBQVMsRUFBRTtJQUMvQixNQUFNLEdBQUcsR0FBRyxNQUFNLElBQUEscUJBQUssRUFBQyw4Q0FBOEMsQ0FBQyxDQUFDO0lBQ3hFLDhCQUE4QjtJQUM5QixNQUFNLElBQUksR0FBRyxNQUFNLEdBQUcsQ0FBQyxJQUFJLEVBQWMsQ0FBQztJQUMxQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDMUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxjQUFjLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ3hDLE9BQU8sQ0FBQyxHQUFHLENBQUMsa0JBQWtCLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0FBQ3BELENBQUMsQ0FBQSxDQUFBO0FBRUQscUJBQXFCO0FBRXJCLDBEQUEwRDtBQUUxRCxNQUFNLFFBQVE7SUFTVixZQUFZLEtBQWEsRUFBRSxPQUFlLEVBQUUsV0FBbUI7UUFDM0QsSUFBSSxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7UUFDbkIsSUFBSSxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUM7UUFDdkIsSUFBSSxDQUFDLFdBQVcsR0FBRyxXQUFXLENBQUM7SUFDbkMsQ0FBQztDQUNKO0FBRUQsTUFBTSxNQUFNLEdBQUcsSUFBSSxRQUFRLENBQUMsQ0FBQyxFQUFFLE1BQU0sRUFBRSxTQUFTLENBQUMsQ0FBQztBQUNsRCxnQkFBZ0I7QUFDaEIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLEVBQUUsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQzNDLGtEQUFrRDtBQUNsRCwwREFBMEQ7QUFFMUQsTUFBTSxXQUFZLFNBQVEsUUFBUTtJQUk5QixZQUFZLEtBQWEsRUFBRSxPQUFlLEVBQUUsV0FBbUIsRUFBRSxNQUFjO1FBQzNFLEtBQUssQ0FBQyxLQUFLLEVBQUUsT0FBTyxFQUFFLFdBQVcsQ0FBQyxDQUFDO1FBQ25DLElBQUksQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDO0lBQ3pCLENBQUM7SUFFRCxPQUFPO1FBQ0gsT0FBTyxDQUFDLEdBQUcsQ0FBQywwQkFBMEIsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDcEQsT0FBTyxDQUFDLEdBQUcsQ0FBQyw0QkFBNEIsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDeEQsbUVBQW1FO0lBQ3ZFLENBQUM7SUFFRCxTQUFTLENBQUMsS0FBYTtRQUNuQixPQUFPLElBQUksQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO0lBQy9CLENBQUM7Q0FDSjtBQUVELE1BQU0sTUFBTSxHQUFHLElBQUksV0FBVyxDQUFDLENBQUMsRUFBRSxPQUFPLEVBQUUsWUFBWSxFQUFFLEtBQUssQ0FBQyxDQUFDO0FBQ2hFLE1BQU0sQ0FBQyxPQUFPLEVBQUUsQ0FBQztBQUNqQixNQUFNLFNBQVMsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3pDLE9BQU8sQ0FBQyxHQUFHLENBQUMsd0JBQXdCLEVBQUUsU0FBUyxDQUFDLENBQUM7QUFFakQsOERBQThEO0FBRTlELDBCQUEwQjtBQUMxQixNQUFNLE9BQU87SUFHVCxZQUFZLElBQVksRUFBRSxHQUFXO1FBQ2pDLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBQ2pCLElBQUksQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDO0lBQ25CLENBQUM7SUFDRCxPQUFPLENBQUMsR0FBVztRQUNmLE9BQU8sTUFBTSxHQUFHLEdBQUcsQ0FBQztJQUN4QixDQUFDO0NBQ0o7QUFFRCxNQUFNLEdBQUcsR0FBRyxJQUFJLE9BQU8sQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDdEMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsRUFBRSxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDNUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsRUFBRSxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDMUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyx1QkFBdUIsRUFBRSxHQUFHLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFFdEQsZ0VBQWdFO0FBQ2hFLDhCQUE4QjtBQUM5QixTQUFTLEtBQUssQ0FBSSxJQUFPO0lBQ3JCLE9BQU8sQ0FBQyxHQUFHLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDO0FBQy9CLENBQUM7QUFDRCxLQUFLLENBQVMsT0FBTyxDQUFDLENBQUM7QUFDdkIsS0FBSyxDQUFTLEdBQUcsQ0FBQyxDQUFDO0FBQ25CLEtBQUssQ0FBVSxJQUFJLENBQUMsQ0FBQztBQU1yQixNQUFNLFlBQVk7SUFDZCxPQUFPLENBQUMsR0FBVztRQUNmLE9BQU8sTUFBTSxHQUFHLEdBQUcsQ0FBQztJQUN4QixDQUFDO0NBQ0o7QUFFRCxNQUFNLFFBQVEsR0FBRyxJQUFJLFlBQVksRUFBRSxDQUFDO0FBQ3BDLE9BQU8sQ0FBQyxHQUFHLENBQUMscUJBQXFCLEVBQUUsUUFBUSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBY3pELE1BQU0sSUFBSSxHQUE0QjtJQUNsQyxPQUFPLEVBQUUsRUFBRSxHQUFHLEVBQUUsRUFBRSxFQUFFLEtBQUssRUFBRSxTQUFTLEVBQUU7SUFDdEMsT0FBTyxFQUFFLEVBQUUsR0FBRyxFQUFFLENBQUMsRUFBRSxLQUFLLEVBQUUsWUFBWSxFQUFFO0lBQ3hDLFNBQVMsRUFBRSxFQUFFLEdBQUcsRUFBRSxFQUFFLEVBQUUsS0FBSyxFQUFFLG1CQUFtQixFQUFFO0NBQ3JELENBQUM7QUFFRixPQUFPLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBWWxCLE1BQU0sSUFBSSxHQUFnQjtJQUN0QixLQUFLLEVBQUUsWUFBWTtJQUNuQixTQUFTLEVBQUUsS0FBSztDQUNuQixDQUFDO0FBRUYsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQWFsQixNQUFNLE9BQU8sR0FBbUI7SUFDNUIsS0FBSyxFQUFFLFlBQVk7SUFDbkIsU0FBUyxFQUFFLEtBQUs7SUFDaEIsU0FBUyxFQUFFLGFBQWE7Q0FDM0IsQ0FBQztBQUVGLE9BQU8sQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMifQ==