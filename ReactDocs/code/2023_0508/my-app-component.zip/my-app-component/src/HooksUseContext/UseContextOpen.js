// import React, { Component } from 'react';
// import { Provider } from './context';
// import UseContextOpenButton from './UseContextOpenButton';

// class UseContextOpen extends Component {

//     state = {
//         open: false
//     };

//     toggle = () => {
//         this.setState({
//             open: !this.state.open
//         });
//     };

//     render() {
//         const { open } = this.state;
//         const contextValue = {
//             open,
//             toggle: this.toggle
//         };
//         return (
//             <Provider value={contextValue}>
//             <div>
//                 <UseContextOpenButton/>
//                 { open && <div>Some Content</div> }
//             </div>
//             </Provider>
//         );
//     }
// }

// export default UseContextOpen;

import React, { useState } from 'react';
import { Provider } from './context';
import UseContextOpenButton from './UseContextOpenButton';

const UseContextOpen = () => {

    const toggle = () => {
        setState(
            (s) => ({
                ...s,
                open: !s.open
            })
        );
    };

    const [state, setState] = useState( {open: false, toggle} );

    return (
        <Provider value={state}>
            <div>
                <UseContextOpenButton/>
                { state.open && <div>Some Content</div> }
            </div>
        </Provider>
    );

}

export default UseContextOpen;