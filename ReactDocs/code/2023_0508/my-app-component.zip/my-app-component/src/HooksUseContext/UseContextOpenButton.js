// import React, { Component } from 'react';
// import { Consumer } from './context';

// class UseContextOpenButton extends Component {
//     render() {
//         return (
//             <div>
//                 <Consumer>
//                     {({open, toggle}) => (
//                         <button onClick={toggle}>{ open ? 'Close' : 'Open' }</button>
//                     )}
//                 </Consumer>
//             </div>
//         );
//     }
// }

// export default UseContextOpenButton;


import React, { useContext } from 'react';
import context from './context';

const UseContextOpenButton = () => {
    const {open, toggle} = useContext(context);
    return <button onClick={toggle}>{ open ? 'Close' : 'Open' }</button>;
}

export default UseContextOpenButton;