const fs = require('fs');

// 1.callback (利用函數傳入參數取得非同步的回傳結果)
// const getData = (callback) => {    
//     // fs.readFile 為非同步請求
//     fs.readFile('./CourseData.json', (err, content) => {
//         callback(content);
//     });    
// };

// const start = () => {
//     getData( (content) => {
//         console.log(content);
//     });    
// };
// start();


// 2. async/await
// await 後面的函式必須搭配回傳Promise
// Promise的參數本身為一個函式
const getData = () => {
    return new Promise( (resolve, reject) => {
        fs.readFile('./CourseData.json', (err, content) => {
            if (err) {
                reject(err); // 失敗
            } else {
                resolve(content); // 成功
            }
        });
    });
};

const start = async () => {
    const data = await getData();
    console.log(data);
};
start();
