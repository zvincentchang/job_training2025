import React, { Component } from 'react';
import Course from './Course';

const api  = 'https://api.hiskio.com/v1/courses?type=attendance&word=python&status=ALL&professions=39&tags=&page=1&limit=20&course_type=COURSE,LIVE';

class CourseApp extends Component {

    state = {
        courses: [ ],
        next: null,
        loading: true
    };

    componentDidMount() {
        // call api 取得課程列表資料
        this.fetchData(api);
        // 實現畫面捲動分頁功能
        window.addEventListener('scroll', this.onScroll);
    }

    // 組件離開的時候呼叫
    componentWillUnmount(){
        // 移除監聽
        window.removeEventListener('scroll', this.onScroll);
    }

    onScroll = () => {
        const {next, loading} = this.state;
        if(loading) return; // 正在讀取
        if(!next) return; // 沒有下一頁

        const scrollY = window.scrollY; // 目前捲到哪
        const innerHeight = window.innerHeight; // 視窗高度
        const scrollHeight = document.body.scrollHeight; // 總共可以捲多高
        if(scrollY + innerHeight >= scrollHeight -100){
            // next 為api下一頁的URL
            this.fetchData(next);
        }
    }

    fetchData = (apiUrl) => {
        // 讀取下一頁把狀態改為讀取中
        this.setState({ loading: true });
        // CALL API 讀取資料清單
        fetch(apiUrl)
        .then((rs) => rs.json())
        .then((courseData) => {
            console.log(courseData);
            this.setState({
                // ...this.state.courses 原有的資料內容
                // ...courseData.data 加上本次查詢的新分頁資料
                courses: [...this.state.courses, ...courseData.data],
                next: courseData.links.next,
                loading: false // 載入完成解除loading
            });
        });
    }

    render() {
        const {courses} = this.state;
        return (
            <div>
                { courses.map( (course) => <Course key={course.id} {...course}/> ) }
            </div>
        );
    }
}

export default CourseApp;