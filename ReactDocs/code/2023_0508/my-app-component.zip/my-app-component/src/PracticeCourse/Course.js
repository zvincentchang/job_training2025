import React, { Component } from 'react';
import style from './Course.module.css';

class Course extends Component {    
    render() {
        const {title, headline, thumbnails, lecturers} = this.props;
        return (
            <div className={style.course}>
                <div
                    className={style.cover}
                    style={{
                        backgroundImage: `url('${thumbnails.w300}')`
                    }}
                />
                <div className={style.info}>
                    <div className={style.title}>{title}</div>
                    <h4>{headline}</h4>
                    {lecturers.map((lecturer) => 
                        <label>{lecturer.username}</label>
                    )}
                </div>
            </div>
        );
    }
}

export default Course;