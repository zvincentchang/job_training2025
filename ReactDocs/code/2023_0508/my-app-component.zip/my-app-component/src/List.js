import React, { Component } from "react";
import Item from './Item';

// 上層主件
// JSX
// text、price稱為props
class List extends Component {
    render(){
        return (
            <ol>
                <Item text="Learn JavaScript" price={100}/>
                <Item text="Learn React" price="100"/>
                <Item text="Make Money"/>
                <Item>Buy a House</Item>
            </ol>
        )
    }
}

export default List;