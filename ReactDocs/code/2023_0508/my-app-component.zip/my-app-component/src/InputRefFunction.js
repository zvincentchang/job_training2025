import React, { Component } from 'react';

class InputRefFunction extends Component {

    // function 參數就是input元素
    setRef = (input) => {
        input.focus();
    }

    render() {
        return (
            <div>
                <h3>Enter your name : ref 指定函數</h3>
                <input type="text" ref={this.setRef}/>
            </div>
        );
    }
}

export default InputRefFunction;