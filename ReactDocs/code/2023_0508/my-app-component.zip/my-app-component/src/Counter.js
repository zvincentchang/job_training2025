import React, { Component } from 'react';
import PropTypes from 'prop-types';
// import { ReactPropTypes } from 'react';

class Counter extends Component {

    static propTypes = {
        initCount: PropTypes.number
    }

    static defaultProps = {
        initCount: 20        
    }

    state = {
        count : this.props.initCount,
        step: 1
    }

    constructor(props){
        super(props);
        this.state = {
            count : props.initCount,
            step: 1
        }
    }

    counterAdd = () => {
        // 解構
        const {count, step} = this.state;

        // this.setState({
        //     count: count + step,
        //     step: step + 1
        // });

        // setState 可傳入 function
        // setState 本身為非同步
        // setState 可傳入 function 改為同步
        // this.setState (
        //     state => (
        //         {
        //             count: state.count + state.step,
        //             step: state.step + 2
        //         }
        //     )
        // );

        // setState 可傳入第二個參數 function callback
        // 可確保 setState 確實有更新完才呼叫別的動作
        this.setState(
            {
                count: count + step,
                step: step + 1
            }, 
            () => {
                this.sendCount();
            }
        );

    }

    sendCount = () => {
        console.log(`count:${this.state.count}`);
        fetch(`/api/count?value=${this.state.count}`);
    }

    // 點幾次就加多少
    render() {
        // 解構
        const {count, step} = this.state;
        return (
            <div>
                <h1>Counter {count}</h1>
                <button onClick={this.counterAdd}>Counter Add Step + {step}</button>
            </div>
        );
    }
}

Counter.defaultProps = {
    initCount: 20
}

Counter.propTypes = {
    initCount: PropTypes.number
}

export default Counter;