import React, { Component, useState } from 'react';

// 使用函式組件(functional component) 就不能直接使用 state 必須透過 Hooks useState(狀態管理)
// 使用 Hooks就可以使用函式組件(functional component)來操作state
const UseStateApp = () => {
    // useState傳入初始的狀態(會回傳一個陣列)
    // 陣列中第一個值(count)代表目前的狀態、第二個為設定狀態的函式(setCount)
    const [count, setCount] = useState(0);
    const addCount = () => {
        setCount(c => c + 1); // 可傳入函式(傳入的參數為舊的state的值)
    };

    return (
        <div>
            <h3>{count}</h3>
            <button onClick={addCount}>Add</button>
        </div>
    );
};

export default UseStateApp;