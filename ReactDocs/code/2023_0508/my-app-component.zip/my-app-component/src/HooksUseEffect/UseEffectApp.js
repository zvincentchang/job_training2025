import React, { useState, useEffect } from 'react';

// 使用函式組件(functional component) 就不能使用生命週期函式 componentDidMount
const UseEffectApp  = () => {

    // useState傳入初始的狀態(會回傳一個陣列)
    // 陣列中第一個值(state)代表目前的狀態、第二個為設定狀態的函式(setState)
    const [ state, setState ] = useState({
        email: '',
        picture: '',
        userVersion: 0
    });

    // 相當於 componentDidMount
    // 於組件每次render更新時執行第一個參數(函式)
    // 第二個參數值陣列用來判斷與前一次呼叫useEffect傳入的第二參數值是否一樣
    // 如果不一樣則會再次呼叫第一個參數的函式
    const { email, picture, userVersion } = state;

    useEffect(() => {

        fetch('https://randomuser.me/api/')
        .then((rs) => rs.json())
        .then((data) => {
            const [user] = data.results;
            setState( (u) => ({
                ...u,
                email: user.email,
                picture: user.picture.medium
            }) );
        });

        const onScroll = () => {};
        window.addEventListener('scroll', onScroll);
        // 相當於 componentWillUnmount 清理函式
        return () => {
            window.removeEventListener('scroll', onScroll);
        };

    }, [ userVersion ]);

    const changeUseEffectValue = () => {
        setState( (u) => ({
            ...u,
            userVersion: userVersion+1
        }) );
    };    

    return (
        <div>
            <img src={picture}/>
            <div>{email}</div>
            <div>{userVersion}</div>
            <button onClick={changeUseEffectValue}>change useEffect value</button>
        </div>
    );
}

export default UseEffectApp;