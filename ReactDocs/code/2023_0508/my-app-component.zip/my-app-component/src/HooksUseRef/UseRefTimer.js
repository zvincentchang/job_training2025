import React, { useRef, useState,Fragment } from 'react'

const UseRefTimer = () => {
    const [ state, setState ] = useState({count:0});
    const ref = useRef();
    const startCount = () => {
        // useRef的儲存是跟隨著各自的組件實例,而非所有組件實例共用
        ref.countID = setInterval(() => setState(c => ({ ...c, count:c.count + 1})), 100);
    };
    const stopCount = () => {
        clearInterval(ref.countID)
    };
    const {  count } = state;
    return (
        <Fragment>
            <h1>{count}</h1>
            <button onClick={startCount}>startCount</button>
            <button onClick={stopCount}>stopCount</button>
        </Fragment>
    );
}

export default UseRefTimer