// import React, { Component, createRef } from 'react';

// class UseRefFocus extends Component {

//     ref = createRef();

//     componentDidMount(){
//         this.ref.current.focus();
//     }

//     render() {
//         return <input ref={this.ref} />;
//     }
// }

// export default UseRefFocus;


import React, { useEffect, createRef, useRef } from 'react';

const UseRefFocus = () => {

    // const ref = createRef();

    // ref 儲存DOM的參照
    // 與createRef差異在不會每次都建立新的ref
    const ref = useRef(); 

    useEffect(()=> {
        ref.current.focus();
    } ,[]);

    return <input ref={ref} />;
};

export default UseRefFocus;