import React, { Component } from 'react';

class Child extends Component {

    state = {
        count: 0
    };

    
    addChildCount = () => {
        this.setState({
            count: this.state.count + 1
        });
    };

    // 父傳子:子元件透過 "props" 呼叫父主件函式
    // this.props.addParentCount
    render() {
        return (
            <div>
                <h3>Child : {this.state.count}</h3>
                <button onClick={this.props.addParentCount}>Add Parent Count</button>
                <button onClick={this.addChildCount}>Add Child Count</button>
            </div>
        );
    }
}

export default Child;