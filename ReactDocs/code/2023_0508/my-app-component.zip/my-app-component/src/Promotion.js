import React, { Component } from 'react';
import momo from './img/momo.png';

class Promotion extends Component {

    render() {
        const { open, toggleOpen } = this.props;
        return (
            <div>
                <button onClick={toggleOpen}>Promotion</button>
                <hr/>
                {open && <img src={momo}/>}
            </div>
        );
    }
}

export default Promotion;