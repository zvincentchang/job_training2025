import create from "zustand";

// 撰寫Store
// Store可以理解成儲存區, 依照功能名稱或業務邏輯來建立Store, 每一個Store都是獨立的, 裡面的狀態不會互相影響.
const useStoreCount = create((set, get) => ({
  // state初始值
  count: 0,
  // 更新store內的值, state是目前狀態
  add: () => set((state) => ({ count: state.count + 1 })),  
  inputNo: 0,
  // 函式單行寫法, val是外面傳進來要設定的值
  changeInputNo: (val) => set({ inputNo: parseInt(val) }),
  addNumber: (number) => {
    // 如果函式裡需要取得Store內的變數進行處理, 可以使用get.
    const currentCount = get().count; 
    set({ count: currentCount + number });
  }
}));

export default useStoreCount;