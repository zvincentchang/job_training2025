import useStoreCount from "./useStoreCount";

const ZustandCount = () => {
  // 解構 zustand store
  const { count, add, addNumber, inputNo, changeInputNo } = useStoreCount();

  const onChangeText = (e) => {
    changeInputNo(e.target.value);
  };

  const clickAddNumber = () => {
    addNumber(inputNo);
  };

  return (
    <div>
      <p>{count}</p>
      <button onClick={add}>Add</button>
      <hr/>
      <p>{inputNo}</p>
      <input type="number" onChange={onChangeText} /><br/>
      <button onClick={clickAddNumber}>addNumber</button>
    </div>
  );
};

export default ZustandCount;