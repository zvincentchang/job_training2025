import React, { Component } from 'react';
import momo from './img/momo.png';
import './css/style.css';

class CtrlStyle extends Component {

    state = {
        visible: true
    };

    toggle = () => {
        this.setState({
            visible: !this.state.visible
        });
    };

    render() {
        const { visible } = this.state; 
        const styleObj = { display: visible ? 'block' : 'none' };
        // const classObj = visible ? 'imageShow' : 'imageHide';
        // 前後`頓號表示為字串模版，透過${}抓值
        const classObj = `${visible ? 'imageShow' : 'imageHide'}`; 

        return (
            <div>
                <button onClick={this.toggle}>Toggle</button>
                <hr/>
                三元運算子、判斷式 <br/>
                {visible ?  <img src={momo}/> : null}
                {visible && <img src={momo}/>}
                <br/>
                控制 style JSX 物件 <br/>
                <img style={styleObj} src={momo}/>
                <img style={{ display: visible ? 'block' : 'none' }} src={momo}/>
                <br/>
                控制 className (style.css) <br/>
                <img className={classObj} src={momo}/>
                <img className={ `${visible ? 'imageShow' : 'imageHide'}`} src={momo}/>
            </div>
        );
    }
}

export default CtrlStyle;