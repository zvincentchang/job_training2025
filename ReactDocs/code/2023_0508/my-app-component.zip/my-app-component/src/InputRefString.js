import React, { Component } from 'react';

class InputRefString extends Component {

    componentDidMount(){
        this.refs.myInput.focus();
    }


    render() {
        return (
            <div>
                <h3>Enter your name : ref 指定字串</h3>
                <input type="text" ref="myInput"/>
            </div>
        );
    }
}

export default InputRefString;