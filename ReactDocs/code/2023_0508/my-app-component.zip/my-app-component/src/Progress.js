import React, { Component, PureComponent } from 'react';
import ProgressBar from './ProgressBar';

// PureComponent 也會比較自已的state
// shallow compare 淺層比較 (只比較 propse 與 state 的第一層)
// 只有第一層值有更新時才會render
class Progress extends PureComponent {

    state = {
        value: 0,
        info: {
            x: 0
        }
    };

    add = () => {
        const { info } = this.state;
        info.x += 1;
        console.log(`info.x:${info.x}`); // 第二層之後的值有更新也不會重新render
        this.setState({
            // value: this.state.value + 1
            info: info
        });
    }

    render() {
        console.count('Progress PureComponent');
        return (
            <div>                
                <ProgressBar value = {this.state.value}/>
                <ProgressBar value = {this.state.info.x}/>
                <button onClick={this.add}>+</button>            
            </div>
        );
    }
}

export default Progress;