import React, { Component, PureComponent } from 'react';

// 1.class Component
// class ProgressBar extends Component {
//     render() {
//         console.count('ProgressBar Component');
//         const {value} = this.props;

//         return (
//             <div className="bar-outer">
//                 <div
//                     className="bar-inner"
//                     style={{ width: `${value}%` }}
//                 />
//                 <span>{value}%</span>
//             </div>
//         );
//     }
// }

// 2.PureComponent
/*
PureComponent與Component差異在效能上，當上層元件所傳入下層元件的props中的值若"未改變"的話
PureComponent是不會重新render，但Component與Functional Component 都會重新render效能較差
*/
class ProgressBar extends PureComponent {
    render() {
        console.count('ProgressBar PureComponent');
        const {value} = this.props;
        return (
            <div>
                {value}%
            </div>
        );
    }
}

// 3.Functional Component (Statless無狀態)
// 方法元件沒有state可操作故稱為無狀態Statless
// const ProgressBar = (props) => {
//     // 函式直接取代render
//     // render() {
//         const {value} = this.props;
//         return (
//             <div className="bar-outer">
//                 <div
//                     className="bar-inner"
//                     style={{ width: `${value}%` }}
//                 />
//                 <span>{value}%</span>
//             </div>
//         );
//     // }
// }


export default ProgressBar;