import React, { Component } from 'react';

class ComponentLifeCycle extends Component {

    // constructor規則、用法
    // 1.一定要呼叫super
    // 2.會傳入props參數
    // 3.指定 this.state
    // 4.綁定自訂義函式(可用箭頭函式取代)
    // PS:目的讓this為Component自已
    // 5.不要做 this.setState({})
    // 6.不要將props指定到state裡面 this.state = { count:props.count }
    // 7.不要去呼叫資料 fetch ajax 函式

    constructor(props){
        console.log("constructor");
        super(props);
        this.state = { count:0 };
        // this.state = { count:props.count }

        // 將handleClick綁定Component組件自已
        this.handleClick = this.handleClick(this);
    }

    handleClick() {
        // this
    }

    state = {
        items: []
    };

    // 如果你需要從遠端終端點（remote endpoint）請求資料的話, 此處非常適合進行實例化網路請求（network request）
    // 你可以馬上在 componentDidMount() 內呼叫 setState()。這會觸發一次額外的 render，但這會在瀏覽器更新螢幕之前發生。在這個情況下，即使 render() 被呼叫兩次，這確保使用者不會看見這兩次 render 中過渡時期的 state。請謹慎使用這個模式，因為這經常會導致效能問題。
    componentDidMount() {
        console.log("componentDidMount");
        this.fetchList();
    }

    fetchList = async () => {
        const response = await fetch('http://.../api/list');
        const data = await response.json();
        this.setState({
            items: data
        });
    }

    // render 渲染函式
    // 1.this.props、this.state
    // 2.不要做 this.setState({})
    // 3.不要去呼叫資料 fetch ajax 函式
    // 4.專責做畫面呈現
    render() {
        console.log("render");
        // this.props;
        const { items } = this.state;
        // 要回傳一個JSX元素
        // React16之後可以return array
        // return <div onClick={this.handleClick}>{this.state.count}</div>
        // return <div onClick={this.handleClick}>{this.props.count}</div>
        return [
            <div>{this.props.count}</div>,
            <div>{this.props.count}</div>,
            <ul>
                {items.map((item) => 
                    <li key={item.id} >{item.text}</li>
                )}
            </ul>
        ];
    }

}

export default ComponentLifeCycle;