import React, { Component } from 'react';

class Message extends Component {
    // 事件處理與狀態更新
    // 組件狀態:state 與 setState
    // state 主件狀態
    // state 狀態可部份更新(Partial update)屬性值 
    state = {
        title: 'Message',
        text: 'Hello'
    }

    constructor(props){
        super(props);
        // 透過建構式再綁定回主件 bind(this)
        this.updateState = this.updateState.bind(this);
    }

    // updateState = () => {
        // 鍵頭函式裡的this就等於這個主件
    //     this.setState (
    //         { text: 'Hello React' }
    //     );
    // }

    updateState() {
        // 此時的this指的是button而非React的主件
        // 1.改成鍵頭函式
        // 2.透過建構式再綁定回主件bind(this)
        this.setState (
            { text: 'Hello React' }
        );
    }

    render() {
        return (
            <div>
                <h1>{this.state.title}</h1>
                <h3>{this.state.text}</h3>
                <button onClick={this.updateState}>update state</button>
            </div>
        );
    }    
}

export default Message;