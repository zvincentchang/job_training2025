import React, { Component } from 'react';
import Product from './Product';
import productsData from './productsData.json';

class ProductList extends Component {

    render() {

        const products = productsData;
        // const { addOrder } = this.props;

        return (
            <ul>
                {products.map(                    
                    // product => <Product {...product} key={product.id} addOrder={addOrder}/>
                    // App → ProductList → Product
                    // 透過Context API 就不須要再轉一手傳入addOrder函數
                    product => <Product {...product} key={product.id} />
                )}
            </ul>
        );
    }
}

export default ProductList;