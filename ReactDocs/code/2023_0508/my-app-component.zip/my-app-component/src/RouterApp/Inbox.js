import React from 'react'
import { useParams } from "react-router-dom";

export default function Inbox() {
  let params = useParams();
  return (
    <div>
      <h2>Inbox</h2>
      Welcome to your Inbox {params.id}
    </div>
  )
}
