import React, { Component } from 'react';

const relations = [ '父','母','子','女','妻','友' ];

const relationsObj = [ 
    {label: '父', value: 0},
    {label: '母', value: 1},
    {label: '子', value: 2},
    {label: '女', value: 3},
    {label: '妻', value: 4},
    {label: '友', value: 5} 
];

class FormText extends Component {

    state = {
        text: "abc",
        count: 0,
        rel: relations[0],
        // 下拉選單的值為字串
        relObj: `${relationsObj[0].value}` 
    };

    onChangeText = (even) => {
        this.setState ({
            text: even.target.value
        });
    };

    onChangeNumber = (even) => {
        this.setState ({
            count: parseInt(even.target.value)
        });
    };

    onChangeSelect = (even) => {
        this.setState({
            rel: even.target.value
        })
    }

    onChangeSelectObj = (even) => {
        this.setState({
            relObj: even.target.value
        })
    }

    render() {
        const {text, count, rel, relObj} = this.state;
        return (
            <div>
                <input type="text" value={text} onChange={this.onChangeText}/>
                <br/>
                <textarea value={text} onChange={this.onChangeText}/>
                <h3>{text}</h3>
                <hr/>

                <input type="number" value={count} onChange={this.onChangeNumber}/>
                <h3>{ count + 1 }</h3>

                <hr/>

                <select onChange={this.onChangeSelect}>
                    {relations.map( (element, idx) => 
                        <option key={element}>{element}</option>
                    )}
                </select>
                <h3>{rel}</h3>

                <hr/>

                <select onChange={this.onChangeSelectObj}>
                    {relationsObj.map( (element, idx) => 
                        <option key={element.label} value={element.value}>{element.label}</option>
                    )}
                </select>
                <h3>{relObj}</h3>

                {/* 
                    r.value:數字、relObj:字串 
                    == 兩個等於只比較值
                    === 三個等於比較值與型態
                */}
                <h3>{ relationsObj.find( r => r.value == relObj).label }</h3>
                {/* r.value 透過字串模版轉字串 */}
                <h3>{ relationsObj.find( (r) => `${r.value}` === relObj).label }</h3>
            </div>
        );
    }
}

export default FormText;