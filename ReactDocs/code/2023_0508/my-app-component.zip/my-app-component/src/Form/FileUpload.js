import React, { Component } from 'react';
import axios from "axios";

class FileUpload extends Component {

    state = {
        img: '',
        imgFile: null
    };

    onChangeImg = (e) => {
      const file = e.target.files.item(0);
      const fr = new FileReader();
      fr.addEventListener('load', this.fileLoad)
      // 讀取檔案轉為 base64 DataURL 
      fr.readAsDataURL(file);

      this.setState({
        imgFile: file
      });
    };

    fileLoad = (e) => {
        // 取得 DataURL
        this.setState({
            img: e.target.result
        });
    }

    submit = () => {
        // json base64
        // axios.post('/img', {img: this.state.img});

        // multipart
        const form = new FormData();
        form.append("imgFile", this.state.imgFile);
        axios.post('/img', {form});
    };

    render() {
        const { img,imgFile } = this.state;
        return (
            <div>
                <input type="file" onChange={this.onChangeImg}/>
                <img width="100%" src={img}/>
                {img}                
                <button onClick={this.submit}>Submit</button>
            </div>
        );
    }
}

export default FileUpload;