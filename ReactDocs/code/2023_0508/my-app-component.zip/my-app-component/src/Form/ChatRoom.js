import React, { Component } from 'react';

class ChatRoom extends Component {

    state = {
        text: '',
        content: []
    };

    onChangeText = (e) => {
        this.setState({
            text: e.target.value
        });
    };

    submit = (e) => {        
        e.preventDefault(); // submit預設會換頁,把預設的行為擋下來
        const { text,content } = this.state;
        this.setState({
            text: '', // 表單送出後把輸入框文字清空
            content: [ {id: Date.now(), text}, ...content ]
        });
    };

    render() {
        const { text,content } = this.state;
        return (
            <div>
                {/* input 輸入框按Enter會觸發form onSubmit */}
                <form  action='textAction' onSubmit={this.submit}>
                    <input type="text" value={text} onChange={this.onChangeText}/>
                    {/* <button onClick={this.submit}>submit</button> */}
                    <button type="submit">submit</button>
                </form>
                <ul>
                    { content.map( (item) => <li key={item.id}> {item.text} </li> ) }
                </ul>
            </div>
        );
    }
}

export default ChatRoom;