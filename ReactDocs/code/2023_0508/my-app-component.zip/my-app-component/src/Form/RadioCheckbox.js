import React, { Component } from 'react';

class RadioCheckbox extends Component {

    state = {
        gender: 'male',
        like: {
            male: false,
            female: false
        }
    };

    onChangeRadio = (e) => {
        this.setState({
            gender: e.target.value
        })

    };

    onChangeCheckbox = (e) => {
        const key = e.target.value;
        this.setState( (state) => ( {
            like: {
                // 複制原先的 like 物件內容
                ...this.state.like,
                // 針對指定的 like 更新欄位值
                [key] : !state.like[key]
            }
        }));
    };

    render() {
        const { gender, like } = this.state;
        return (
            <div>
                <div>
                    Your gender:
                    <input type="radio" value="male"
                           onChange = {this.onChangeRadio}
                            // radio 透過gender的值來控制是否要選中 checked
                           checked= {gender === 'male' }
                    />
                    <label>Male</label>
                    <input type="radio" value="female" 
                        onChange={this.onChangeRadio}
                        checked= {gender === 'female' }
                    />
                    <label>Female</label>
                    <pre>{gender}</pre>
                </div>
                <div>
                    Your Like:
                    <input type="checkbox" value="male" onChange={this.onChangeCheckbox} checked={like.male}/>
                    <label>Male</label>
                    <input type="checkbox" value="female" onChange={this.onChangeCheckbox} checked={like.female}/>
                    <label>Female</label>
                    <pre>{JSON.stringify(this.state, null, 2)}</pre>
                </div>
            </div>
        );
    }
}

export default RadioCheckbox;