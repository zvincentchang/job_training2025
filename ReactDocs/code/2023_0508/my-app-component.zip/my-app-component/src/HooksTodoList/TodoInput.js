import React, { useState, useRef, useEffect, useContext } from 'react'
import context from './context';

// const TodoInput = ({ addItem }) => {
const TodoInput = () => {

    // const { addItem } = props;

    // addItem來至於父層組件(TodoList)
    const { addItem } = useContext(context);

    const [text, setText] = useState('');

    const ref = useRef();

    useEffect(
        () => {
            ref.current.focus();
        },[]        
    );

    const onChangeText = e => {
        setText(e.target.value);
    };

    const onSubmit = e => {
        e.preventDefault(); // 防止預設submit送出跳頁行為        
        addItem(text);
        setText('');
    };

    return (
        <div>
            <form onSubmit={onSubmit}>
                <input type="text" ref={ref} value={text} onChange={onChangeText} />
                <button type="submit">Submit</button>
            </form>
        </div>
    )
}

export default TodoInput
