import React, { useState, useEffect } from 'react'
import TodoInput from './TodoInput';
import { Provider } from './context';
import axios from "axios";

const App = () => {

    const [users, setUsers] = useState([]);

    const apiUrl  = 'https://jsonplaceholder.typicode.com/posts/1/comments';
    useEffect(
        () => {
            // fetchCourseData(apiUrl);
            axiosCourseData(apiUrl);
        },[]
    );
    
    // axios 是一個基於 Promise 的 HTTP 客戶端，專門服務於瀏覽器和 node.js 。 
    // 1.基於 Promise 實現
    // 2.自動 cache error 不須額外處理
    // 3.支援 timeout
    // 4.自動轉換 JSON 資料格式
    const axiosCourseData = async (apiUrl) => {
        const { data } = await axios.get(apiUrl, {timeout: 3000})
        .then(rs => {
            console.log(rs.data);
            return rs;
        })
        .catch(error => {
            console.log(error);
        });

        setUsers(users => [...users, ...data]);
    };

    // fetch 是原生 API 能直接使用
    // 1.基於 Promise 實現
    // 2.對 4xx、5xx 都當做成功的請求，需要封裝去處理必須拋出(throw Error)錯誤
    // 3.不支援 timeout
    // 4.不自動轉換 JSON 資料格式
    const fetchCourseData = async (apiUrl) => {
        await fetch(apiUrl)
        .then(rs => {            
            if (!rs.ok) {
                throw Error(rs.status);
            }
            const rsJson = rs.json();
            console.log(rsJson);
            return rsJson;
        })
        .then((courseData) => {
            setUsers(courseData);
        })
        .catch(error => {
            console.log(error);
        });
    };

    const addItem = text => {
        setUsers(oldUsers =>            
            [...oldUsers, {id: oldUsers[oldUsers.length-1].id+1, email:text}]
        );
    };

    const removeItem = id => {
        setUsers(users.filter(user => user.id !== id));
    };

    const contextValue = { addItem }; // contextValue必須包成物件

    return (
        <div>
            <Provider value={contextValue}>
                {/* <TodoInput addItem = {addItem}/> */}
                <TodoInput/>
            </Provider>            
            <ul>
                {users.map(user => 
                    <li onClick={() => removeItem(user.id)} key={user.id}>{user.id}.{user.email}</li>
                )}
            </ul>
        </div>
    );
}

export default App
