import React, { Component, createRef } from 'react';
import Child from './Child';

class Parent extends Component {

    childRef = createRef();

    state = {
        count: 0
    };

    addParentCount = () => {
        this.setState({
            count: this.state.count + 1
        });
    };

    addChildCount = () => {
        // 父傳子透過 "ref" 呼叫子主件函式 addChildCount()
        this.childRef.current.addChildCount();
    };

    // 父傳子:子元件透過 "props" 呼叫父主件函式
    // 子傳父:父元件透過 "ref" 呼叫子主件函式
    // <Child ref={this.childRef} addParentCount={this.addParentCount}/>
    render() {
        return (
            <div>
                <h3>Parent : {this.state.count}</h3>
                <button onClick={this.addParentCount}>Add Parent Count</button>
                <button onClick={this.addChildCount}>Add Child Count</button>

                <Child ref={this.childRef} addParentCount={this.addParentCount}/>
            </div>
        );
    }
}

export default Parent;