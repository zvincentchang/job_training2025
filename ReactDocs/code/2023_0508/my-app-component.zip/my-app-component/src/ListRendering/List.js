import React, { Component } from "react";
import Item from './Item';
import ItemObj from './ItemObj';

const steps = [
    'Learn JavaScript',
    'Learn React',
    'Make Money',
    'Buy a House'
];

const infoOne = { name: 'React Lesson', price: 3200, videos: 60, teacher: 'scars'};

const infoTwo = { name: 'Java', price: 5500, videos: 75, teacher: 'Shang' };

const infoThree = { name: 'Vue', price: 4500, videos: 45, teacher: 'Mark' };

const infos = [infoOne, infoTwo, infoThree];


// 上層主件
// List Rendering 列表渲染
// map javascript 陣列內建函式
class List extends Component {

    state = {
        list: infos
    };

    removeFirst = () => {
        this.setState({
            // 抓取第一個之後的所有陣列元素
            list: this.state.list.slice(1)
        });
    }

    render(){
        return (
            <div>
                {steps.map(
                     (text,index) => <Item>{index} {text}</Item> 
                )}
                <hr/>
                {Object.keys(infoOne).map( (infoKey) => { 
                        const infoValue = infoOne[infoKey];
                        return <Item>{infoKey} : {infoValue}</Item>;
                    }
                )}
                {infoOne.name}、{infoOne.price}、{infoOne.teacher}
                <hr/>
                {infos.map(
                     (info) => <Item>{info.name}、{info.price}、{info.teacher}</Item>
                )}
                <hr/>
                {/* 物件解構 */}
                {infos.map(
                     ({name,price,videos,teacher}) => <Item>{name}、{price}、{videos}、{teacher}</Item>
                )}
                <hr/>
                {/*                     
                    1.元件屬性key作用:讓每一個render的物件都認得與資料的連結
                    2.移除第一個ItemObj的時候，其它ItemObj不該重新被render,使用key(須為唯一值)搭配 PureComponent
                    Warning: Each child in a list should have a unique "key" prop.
                    3.不因該使用index當作key(只能避免Warning)，因從後端資料欄位挑選物件唯一值
                    
                    PS.前後`頓號表示為字串模版，透過${}抓值 
                */}
             
                {this.state.list.map(
                     (info, index) => 
                                <ItemObj 
                                    key={info.name}
                                    // key={index}
                                    info={info} 
                                    infoConent={`${info.price}/${info.videos}/${info.teacher}`}                                
                                />
                )}
                <button onClick={this.removeFirst}>-</button>
            </div>
            
        )
    }
}

export default List;