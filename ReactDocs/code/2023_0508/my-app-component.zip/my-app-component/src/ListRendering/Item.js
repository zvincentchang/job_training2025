import React, { Component } from "react";

// 下層主件
class Item extends Component {
    
    render(){
        return (
             <li>{this.props.children}</li>             
        )
    }

}

export default Item;