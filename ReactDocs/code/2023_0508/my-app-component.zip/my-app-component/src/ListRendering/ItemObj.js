import React, { Component,PureComponent } from "react";

// 下層主件
class Item extends PureComponent {
    // PureComponent : 若props沒有改變則不會重新render
    render(){
        console.info('render', this.props.info.name);
        return <li>{this.props.info.name} : {this.props.infoConent}</li>
    }

}

export default Item;