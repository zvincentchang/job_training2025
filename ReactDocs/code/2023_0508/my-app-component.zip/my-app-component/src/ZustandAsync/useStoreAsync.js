import create from "zustand";
import axios from "axios";

const useStoreAsync = create((set, get) => ({
    // state初始值
    inputUserID: 1,
    changeInputUserID: (val) => set({ inputUserID: parseInt(val) }),
    user: {},
    queryUser: async (userID) => {
        const userData = await axios.get(
            'https://jsonplaceholder.typicode.com/posts/'+`${userID}`,
            {timeout: 3000}
        )
        .then(rs => {
            console.log(rs.data);
            return rs.data;
        })
        .catch(error => {
            console.log(error);
        });

        set({ user: await userData }); // await可省略
    }
}));

export default useStoreAsync;
