import useStoreAsync from "./useStoreAsync";

const ZustandAxios = () => {

    // 解構 zustand store
    const {user, queryUser, inputUserID, changeInputUserID} = useStoreAsync();
    
    const onChangeText = (e) => {
        changeInputUserID(e.target.value);
    };

    const clickQueryUser = () => {
        queryUser(inputUserID);
    };

    return (
        <div>
            <p>id:{user.id}</p>
            <p>title:{user.title}</p>
            <p>body:{user.body}</p>
            <hr/>
            {inputUserID}
            <br/>
            <input type='number' onChange={onChangeText} value={inputUserID} min='1'/>
            <button onClick={clickQueryUser}>QueryUser</button>
        </div>
    )
}

export default ZustandAxios
