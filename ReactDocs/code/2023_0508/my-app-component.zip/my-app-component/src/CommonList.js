import React, { Component } from 'react';

// 父原件
// 文字過濾 withName.js
// 文字新增 withTodo.js
class NameList extends Component {
    render() {
        const {text, items, onChangeText, onSubmit} = this.props;
        return (
            <ul>
                <form onSubmit = {onSubmit}>
                    <input value={text} onChange = {onChangeText}/>
                    <button type="submit">Submit</button>
                </form>
                {
                    items.map( item => (
                        <li>{item}</li>
                    ))
                }
            </ul>
        );
    }
}

export default NameList;