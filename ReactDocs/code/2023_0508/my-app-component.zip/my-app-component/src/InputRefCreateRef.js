import React, { Component, createRef } from 'react';

class InputRefCreateRef extends Component {
    // createRef() 籍由 import createRef 使用
    myInput = createRef();

    componentDidMount(){
        this.myInput.current.focus();
    }

    render() {
        return (
            <div>
                <h3>Enter your name : ref createRef</h3>
                <input type="text" ref={this.myInput}/>
            </div>
        );
    }
}

export default InputRefCreateRef;