import React, { Component } from 'react';
import { createPortal } from 'react-dom';

class LessonModal extends Component {
    render() {
        return createPortal (
            <div>LessonModal</div>,
            document.getElementById('modal')
        );
    }
}

export default LessonModal;