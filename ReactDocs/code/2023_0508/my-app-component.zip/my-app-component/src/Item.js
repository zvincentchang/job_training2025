import React, { Component } from "react";

// 下層主件
class Item extends Component {
    
    render(){
        return (
             <li>
                {this.props.text}  {this.props.price + 1} {this.props.children}
             </li>
        )
    }

}

export default Item;