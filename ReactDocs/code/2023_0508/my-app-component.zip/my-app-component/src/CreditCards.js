import React, { Component } from 'react';
import pchome from './img/pchome.jpg';

class CreditCards extends Component {

    // './hocs/withOpen' 共用原件
    render() {
        const { open, toggleOpen } = this.props;
        return (
            <div>
                <button onClick={toggleOpen}>CreditCards</button>
                <hr/>
                {open && <img src={pchome}/>}
            </div>
        );
    }
}

export default CreditCards;