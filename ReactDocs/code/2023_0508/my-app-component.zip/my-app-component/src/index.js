import React from 'react';
import ReactDOM from 'react-dom';
import { render } from 'react-dom';

import List from "./List";
import Message from "./Message";
import Counter from "./Counter";

// import './css/index.css';
import Calculate from "./Calculate";

import InputRefString from "./InputRefString";
import InputRefFunction from "./InputRefFunction";
import InputRefCreateRef from "./InputRefCreateRef";

import Parent from "./Parent";
import ParentTwo from "./ParentTwo";

import CtrlStyle from './CtrlStyle';

import Progress from './Progress';

import App from './App';
import App2 from './App2';

import ListRendering from './ListRendering/List';

import ArrayFunction from './ArrayFunction';

import FormText from './Form/FormText';
import RadioCheckbox from './Form/RadioCheckbox';
import FileUpload  from './Form/FileUpload';
import ChatRoom from './Form/ChatRoom';

import ComponentLifeCycle from './ComponentLifeCycle';
import Profile from './Profile';
import CourseApp from './PracticeCourse/CourseApp';

import Render from './Render';
import RouterDom from './RouterApp/RouterDom';

import Lesson from './Portal/Lesson';

import ContextApp from './Context/App';

import UseStateApp from './HooksUseState/UseStateApp';
import UseStateApp2 from './HooksUseState/UseStateApp2';
import UseEffectApp from './HooksUseEffect/UseEffectApp';
import UseContextOpen from './HooksUseContext/UseContextOpen';
import UseRefFocus from './HooksUseRef/UseRefFocus';
import UseRefTimer from './HooksUseRef/UseRefTimer';
import HooksTodoList from './HooksTodoList/TodoList.js';

import ZustandCount from './Zustand/ZustandCount';
import ZustandAxios from './ZustandAsync/ZustandAxios';

import GridSystem from './Bootstrap/GridSystem';
import Components from './Bootstrap/Components';
import Carousels from './Bootstrap/Carousels';

// ReactDOM.render(<List/>, document.getElementById('root'));
// ReactDOM.render(<Message/>, document.getElementById('root'));

// ReactDOM.render(<Counter initCount={10}/>, document.getElementById('root'));

// 特意不給 props initCount={10} 下層主件透過 defaultProps 指定 props
// ReactDOM.render(<Counter/>, document.getElementById('root'));

// 特意initCount指定錯誤的型別String 下層主件透過 propTypes 檢查 props 型別
// Warning: Failed prop type: Invalid prop `initCount` of type `string` supplied to `Counter`, expected `number`.
// ReactDOM.render(<Counter initCount="10"/>, document.getElementById('root'));

// 計算機作業
// render(<Calculate/>, document.getElementById('root'));


// render(<InputRefString/>, document.getElementById('root'));
// render(<InputRefFunction/>, document.getElementById('root'));
// render(<InputRefCreateRef/>, document.getElementById('root'));

// render(<Parent/>, document.getElementById('root'));
// render(<ParentTwo/>, document.getElementById('root'));

// render(<CtrlStyle/>, document.getElementById('root'));


// render(<Progress/>, document.getElementById('root'));

// render(<App/>, document.getElementById('root'));
// render(<App2/>, document.getElementById('root'));

// ReactDOM.render(<ListRendering/>, document.getElementById('root'));

// ReactDOM.render(<ArrayFunction/>, document.getElementById('root'));

// ReactDOM.render(<FormText/>, document.getElementById('root'));
// ReactDOM.render(<RadioCheckbox/>, document.getElementById('root'));
// ReactDOM.render(<FileUpload/>, document.getElementById('root'));
// ReactDOM.render(<ChatRoom/>, document.getElementById('root'));

// ReactDOM.render(<ComponentLifeCycle/>, document.getElementById('root'));
// ReactDOM.render(<Profile/>, document.getElementById('root'));
// ReactDOM.render(<CourseApp/>, document.getElementById('root'));

// ReactDOM.render(<Render/>, document.getElementById('root'));
// ReactDOM.render(<RouterDom/>, document.getElementById('root'));

// ReactDOM.render(<Lesson/>, document.getElementById('app'));

// ReactDOM.render(<ContextApp/>, document.getElementById('app'));

// ReactDOM.render(<UseStateApp/>, document.getElementById('app'));
// ReactDOM.render(<UseStateApp2/>, document.getElementById('app'));
// ReactDOM.render(<UseEffectApp/>, document.getElementById('app'));
// ReactDOM.render(<UseContextOpen/>, document.getElementById('app'));
// ReactDOM.render(<UseRefFocus/>, document.getElementById('app'));
// ReactDOM.render(<UseRefTimer/>, document.getElementById('app'));
// ReactDOM.render(<HooksTodoList/>, document.getElementById('app'));
// ReactDOM.render(<ZustandCount/>, document.getElementById('app'));
// ReactDOM.render(<ZustandAxios/>, document.getElementById('app'));

// ReactDOM.render(<GridSystem/>, document.getElementById('app'));
ReactDOM.render(<Components/>, document.getElementById('app'));
// ReactDOM.render(<Carousels/>, document.getElementById('app'));


