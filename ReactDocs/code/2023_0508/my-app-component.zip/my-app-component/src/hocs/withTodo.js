import React, { Component } from 'react';

// 文字新增
export default WrappedComponent => class extends Component {

    state = {
        items: [],
        text: ''
    };

    onChangeText = e => {
        this.setState({
            text: e.target.value
        });
    };

    onSubmit = e => {
        e.preventDefault();
        const {text, items} = this.state;
        const appendItem = [...items, text];
        this.setState({
            items: appendItem
        });        
    };

    render() {
        const {items, text} = this.state;
        return <WrappedComponent            
                {...this.props}
                items={items}
                text={text}
                onChangeText={this.onChangeText}
                onSubmit={this.onSubmit}
        />        
    }
};