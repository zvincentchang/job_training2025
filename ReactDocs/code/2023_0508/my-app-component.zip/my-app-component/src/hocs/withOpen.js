import React, { Component } from 'react';


const withOpen = (WrappedComponent) => {
    return class extends Component {
        state = {
            open: false
        };
    
        toggle = () => {
            this.setState({
                open: !this.state.open
            });
        };

        // {...this.props} 必須傳入
        // 上層主件(withOpen)在傳入給下層主件時才會繼續傳遞下層主件
        render() {
            return (
                <WrappedComponent 
                    {...this.props}
                    open = {this.state.open }
                    toggleOpen = {this.toggle}                    
                />
            )        
        }
    }
}

export default withOpen;