import React, { Component } from 'react';
import names from './names.json';

// 文字過濾
export default WrappedComponent => class extends Component {

    state = {
        items: names,
        text: ''
    };

    onChangeText = e => {
        this.setState({
            text: e.target.value
        });
    };

    onSubmit = e => {
        e.preventDefault();
        const {text} = this.state;
        const filterItem = names.filter(name => name.includes(text));
        this.setState({
            items: filterItem
        });        
    };

    render() {
        const {items, text} = this.state;
        return <WrappedComponent            
                {...this.props}
                items={items}
                text={text}
                onChangeText={this.onChangeText}
                onSubmit={this.onSubmit}
        />        
    }
};