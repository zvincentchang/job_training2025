import React, { Component } from 'react';

class Profile extends Component {

    state = {
        userData: { }
    };

    // 第一次繪制進入到頁面的時候呼叫
    componentDidMount() {
        // window.addEventListener('scroll', this.onScroll);
        this.fetchUser('123');

    }

    onScroll = () => {};

    // 只要上層更新Props都會呼叫
    componentDidUpdate(prevProps, prevState) {
        // 上一個與下一個 props userID 比較
        if(prevProps.userID !== this.props.userID){
            // this.fetchUser('123');
            // this.setState({ });
        }        
    }

    fetchUser = (userID) => {
        // fetch(`http://localhost:8080/api/user/${userID}`)
        fetch(`http://localhost:8085/JavaEE_jQuery/UserProfile?userID=${userID}`)
            .then((rs) => rs.json())
            .then((data) => {
                console.log(data);
                this.setState({
                    userData: data
                });
            });
    };

    // 組件離開的時候呼叫
    componentWillUnmount(){
        // 取消監聽
        // window.removeEventListener('scroll', this.onScroll);
    }

    render() {
        const {userData} = this.state;
        return (
            <div>
                <h3>{userData.name}</h3>
                <h3>{userData.picture}</h3>
            </div>
        );
    }
}

export default Profile;