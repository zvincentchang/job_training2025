
import React from 'react';

import withName from './hocs/withName'; // 邏輯
import withTodo from './hocs/withTodo'; // 邏輯
import CommonList from './CommonList';  // 畫面

// 2.不同邏輯元件套用在相同畫面主件(邏輯元件不共用畫面共用)
const NameList = withName(CommonList);
const TodoList = withTodo(CommonList);

const App2 = ()  => (
    <div>
        <NameList/>
        <TodoList/>
    </div>
);

export default App2;