使用工具撰寫Markdown文件 https://dillinger.io/

# spring-boot-restful

## What is Spring?
- Spring Framework 是一個「輕量級」(Lightweight)的容器(Container) 的框架

- Java 的世界中，除了標準的Java SDK(一般稱之為J2SE)外，另外還有一個主要的分支，J2EE(Java 2 Enterprise Edition)，該分支的主要目的在於支援大型組織及企業的分散式運算。J2EE 主要的精神在於將企業邏輯與系統服務區分開來，而其採取的策略就是：在程式設計階段，不考慮系統服務(將系統服務都視為可以取用的資源，在程式中，利用JNDI 來取得這些資源)。但J2EE因其複雜性及必須先安裝在特定的環境中，然後利用部署機制來運作，這種類型的Container 稱之為「重量級容器」(Heavy Weight Container)。這種繁複的系統配置，也造成了開發人員的困擾。

- 反觀Spring Framework 的結構設計，所有的企業服務都利用POJO(Plain Old Java Object)來進行設計，在實作上，不包含任何除了標準Java 語言外其他的平台限制，而當其他的物件(無論是Web 的物件或是其他的Client 物件)要去使用該服務時，只要透過使用者定義的企業介面(Business Interface)來進行存取就可以了。

- 至於跟後端的企業資源溝通，也都可以透過標準的OR Mapping (Object- Relationship Mapping)機制就可以了，其中所使用到的，也都是POJO 的Java Bean。由於使用POJO 的關係，企業邏輯與平台(這裡指的是實際運作的平台)沒有必然的關係，你可以任意選擇要將你的程式部署在單純的Web Container(如Tomcat)，或是標準的J2EE Server(如Weblogic, Websphere 或是JBoss)，甚或是單獨運作的JVM 上。由於企業邏輯的程式具備了可攜性，基於Spring Framework 所實作出來的程式也具備了可攜性，這也是為什麼稱Spring Framework 是一個「輕量級」容器的緣故。
 

Spring Framework 的應用程式模組則如下圖所示
![N|Solid](https://raw.githubusercontent.com/yushlee/spring-boot-restful/master/doc/img/What%20is%20Spring.png)

## How Spring Works?
- Spring 最成功的是其提出的理念，而不是技術本身，Spring Framework 依賴的2個核心理念
    - 一個是採用所謂控制反轉 IoC(Inversion of Control) 的實作技術，來實現其追求輕量化的結構目標。 IoC container是 Spring的核心，可以說 Spring 是一種基於 IoC container 開發的框架
    - 另一個是切面編程導向 AOP(Aspect Oriented Programming)

![N|Solid](https://raw.githubusercontent.com/yushlee/spring-boot-restful/master/doc/img/HowSpringWorks_1.png)
![N|Solid](https://raw.githubusercontent.com/yushlee/spring-boot-restful/master/doc/img/HowSpringWorks_2.png)
> 控制反轉是一個設計思想 ，把對於某個物件的控制權移轉給第三方容器
簡單解釋A物件程式內部需要使用B物件 A, B 物件中有依賴的成份
控制反轉是把原本 A 對 B 控制權移交給第三方容器
降低 A 對 B 物件的耦合性，讓雙方都倚賴第三方容器。


## What is Spring Boot?

- Spring Boot 是由 Pivotal 團隊提供的全新框架，該框架使用了特定的方式來進行配置，從而使開發人員不再需要定義樣板化的配置。Spring Boot 預設配置了很多框架的使用方式，就像 Maven 整合了所有的 Jar 包，Spring Boot 整合了所有的框架。

- Spring Boot 簡化了 Spring 應用開發，不需要配置就能運行 Spring 應用， Spring Boot簡化了管理 Spring 容器、協力廠商外掛程式 並提供很多預設系統級的服務。大部分Spring的應用開發，無論是簡單的系統還是構建複雜系統，都只需要少量配置和代碼就能完成。

![N|Solid](https://raw.githubusercontent.com/yushlee/spring-boot-restful/master/doc/img/What%20is%20SpringBoot.png)

![N|Solid](https://raw.githubusercontent.com/yushlee/spring-boot-restful/master/doc/img/SpringBoot_1.png)

![N|Solid](https://raw.githubusercontent.com/yushlee/spring-boot-restful/master/doc/img/SpringBoot_2.png)

![N|Solid](https://raw.githubusercontent.com/yushlee/spring-boot-restful/master/doc/img/SpringBoot_3.png)

## Spring Boot 特性
- Spring Boot 其設計目的是用來簡化新 Spring 應用的初始搭建以及開發過程。上手 Spring 開發更快、更廣泛。
- Spring Boot 的核心思想就是約定大於配置 (convention over configuration)，多數 Spring Boot 應用只需要很少的 Spring 配置，可以使用預設方式實現快速開發。
- 使用注解，使編碼變得簡單。
- 使用自動配置，使配置變得簡單，快速構建專案，快速集成新技術的能力。
- 使部署變得簡單： 內嵌 Tomcat  Jetty Web 容器。
- 採用 Spring Boot 可以 大大的簡化開發模式，所有你想集成的常用框架，它都有對應的組件支援。
自帶應用監控


## Spring Boot 的核心 → 約定優於配置
- 什麼是約定優於配置呢？
約定優於配置（Convention Over Configuration），也稱作按約定程式設計，是一種軟體設計範式，旨在減少軟體發展人員需做決定的數量、獲得簡單的好處，而又不失靈活性。
- 本質是說，開發人員僅需調整應用中不符約定的部分。例如如果模型中有個名爲Sale的類，那麼數據庫中對應的表就會默認命名爲sales。只有在偏離這一約定時，例如將該表命名爲"products_sold"，才需寫有關這個名字的配置。如果您所用工具的約定與你的期待相符，便可省去配置；反之你可以配置來達到你所期待的方式。
- Spring Boot 體系將約定優於配置的思想展現得淋漓盡致，小到設定檔、中介軟體的預設配置，大到內置容器、生態中的各種 Starters 無不遵循此設計規則，Spring Boot 約定優於配置的思想讓 Spring Boot 項目非常容易上手，讓程式設計變得更簡單。

## Spring Boot 的核心 → Starter
- Spring Boot Starters 基於約定優於配置的理念來設計，Spring Boot Starter 中有兩個核心組件：自動配置代碼和提供自動配置模組及其它有用的依賴。也就意味著當我們項目中引入某個 Starter，即擁有了此軟體的預設使用能力，除非我們需要特定的配置，一般情況下我僅需要少量的配置或者不配置即可使用元件對應的功能。
- Spring Boot 由眾多 Starter 組成
    - Spring-boot-starter ，核心 Starter，包括自動配置支援，日誌和 YAML
    - spring-boot-starter-actuator，Actuator 是 SpringBoot 提供的監控功能
    - Spring-boot-starter-cache ，用於使用 Spring 框架的緩存支持
    - Spring-boot-data-jpa ，用於使用 Hibernate 實現 Spring Data JPA
    - Spring-boot-starter-security，對 Spring Security 的支持
    - Spring-boot-starter-test ，用於測試 Spring Boot 應用，支援常用測試類庫，包括 JUnit、Hamcrest 和 Mockito
    - Spring-boot-starter-web ，用於使用 Spring MVC 構建 Web 應用，包括 RESTful。Tomcat 是默認的內嵌容器

## 建置第一個 Spring boot 專案
- 創建 Maven 工程，構建專案結構
- 配置 pom.xml，引用各種 starter 啟動器簡化配置
- 配置 YML 設定檔運行參數
- 運行與測試
- 打包與獨立運行 (Linux 環境指令如下)
mvn clean package
nohup java –jar spring-boot-restful.jar > /dev/null 2>&1 &

- Maven pom.xml
![N|Solid](https://raw.githubusercontent.com/yushlee/spring-boot-restful/master/doc/img/MavenPom.png)

- application.yml
![N|Solid](https://raw.githubusercontent.com/yushlee/spring-boot-restful/master/doc/img/application.yml.png)

## Spring Boot 運作流程
- Spring Boot 啟動核心 annotation @SpringBootApplication
@SpringBootApplication annotation 是 Spring Boot 的核心註解，用註解標注入口類別是應用的啟動類別，透過在啟動類別中的 main 方法中通過 SpringApplication.run(App.class , args) 來啟動 Spring Boot 應用程式。
- SpringBootApplication 註解主要組合了以下註解。 
@Configuration ，這是 Spring Boot 專案的配置註解。
@EnableConfiguration ，啟動自動配置，該註解會讓 Spring Boot 根據當前專案所依賴的 jar 包自動配置專案相關配置
@ComponentScan ，掃描配置，Spring Boot 會掃描SpringBootApplication 的同級目錄以及它的子目錄， 所以建議將＠SpringBootApplication 修飾的入口類放置在主目錄下，這樣做可以保證 Spring Boot 掃描到專案所有的程式。

![N|Solid](https://raw.githubusercontent.com/yushlee/spring-boot-restful/master/doc/img/SpringBoot_4.png)

## Spring boot Swagger
- 建立視覺化可操作 API Swagger 頁面、api-docs文件自動建立
- 設置各不同 Package Controller 於 Swagger 上可以下拉選單區分功能
- Swagger URL
http://localhost:8085/training/swagger-ui/index.html

![N|Solid](https://raw.githubusercontent.com/yushlee/spring-boot-restful/master/doc/img/Swagger.png)

## Spring boot IOC (Inversion of Control)
- 控制反轉（inversion of control，IOC）是一種程式設計的概念，而依賴注入 DI (Dependency Injection) 則是實現這種概念的方式
實務應用上常見的使用方式是，在Service Layer 也就是商業邏輯元件設計出共同要操作使用的 Interface 
並且設計抽象方法再撰寫其 implements 各實作類別，並在實作類別上標注@Service 交由 Spring container 建立實體後
在經由 @Autowired 的方式注入不同的實作（而非使用 new 物件的方式）且型別宣告為介面統一操作
再透過 @Qualifier 的方式明確指定實作類別名稱，以達成依賴關係轉移的動態結果!

- 以下三種為 Spring boot 常見的不同角色服務元件標注
    - @Service
      專案內部所自行選寫的 Business logic Layer 商業邏輯層
    - @Component
      AOP Aspect 元件、呼叫外部第三方系統 API 元件
    - @Repository
      與資料庫交易 Persistence Layer 持久層 DAO (data access object) 元件

![N|Solid](https://raw.githubusercontent.com/yushlee/spring-boot-restful/master/doc/img/IOC.png)

## Spring boot AOP (Aspect Oriented Programming)
- AOP (Aspect Oriented Programming) 面向切面編程
將多個業務流程元件中共同要做的事 (EX：進入方法前後紀錄時間 Log 以計算方法執行時
所需要的時間)，若這些程式散落各處且直接寫在各服務元件之中，很顯然並不是一個好的
做法，將會造成重複的程式碼產生和若是想要移除或加入就必須要修改多隻程式。
我們將這些共用元件收集起來並設計撰寫為@Aspect (切面) 再透過@Pointcut (切入點) 
來決定哪些要被加入切面執行的方法 Joinpoint (加入點)，達到被切面執行的目標程式可以
抽離獨立出來這些切面實作，並且可以動態的決定是否要執行。

- Spring boot 提供了5種 Advice
    - @Before Advice (方法執行前，可修改方法的輸入參數)
    - @After Advice (方法執行後)
    - @AfterReturning Advice (方法執行後，可修改方法的回傳值)
    - @Around Advice (方法執行前/後，可修改方法的回傳值，可決定目標的方法是否執行)
    - @AfterThrowing Advice (方法發生例外錯誤時)
    - @RestControllerAdvice
    統一處理應用程式中全部 Controller Request、Response、與所拋出的 Exception例外錯誤


![N|Solid](https://raw.githubusercontent.com/yushlee/spring-boot-restful/master/doc/img/AOP.png)

## Spring boot RestController
- REST (Representational State Transfer) 表現層狀態轉移
Stateless (無狀態)： Client 端自行保存狀態，在請求 Server 的時候，一併附上給 Server 端，Server 端無保存 Client 端的狀態資訊。
- REST uses various representations to represent a resource like 
text, JSON, XML. JSON (JavaScript Object Notation) is the most popular one
- Use HTTP methods explicitly (i.e. POST, GET, PUT, PATCH, DELETE)
 
![N|Solid](https://raw.githubusercontent.com/yushlee/spring-boot-restful/master/doc/img/HttpMethod.png)

## Microservices 微服務

- 專注於單一責任與功能的小型功能區塊 (Small Building Blocks) 為基礎
- 模組化的方式組合出複雜的大型應用程式，各功能區塊使用與語言無關 (Language-Independent/Language agnostic）的API集相互通訊
- 微服務是一種以業務功能為主的服務設計概念，每一個服務都具有自主運行的業務功能，對外開放不受語言限制的 API (最常用的是 HTTP)
- 拆分每個微服務就可單獨部署及發佈上線，不受其它別的微服務所影響
- 可依照每個微服務所需的系統負載請求量的不同，給予相對的主機硬體支援

## 單體式應用程式架構
單體式應用表示一個應用程式內包含了所有需要的業務功能，每一個業務功能是不可分割
的。若新增或異動其中一個功能就需要整個應用程式下線打包再重新部署上線 (牽一髮而動
全身)，往往應用程式中最吃耗費資源、需要運算資源的僅有某個業務部份（例如跑分析報
表或是數學演算法分析），但因為單體式應用無法分割該部份，因此無形中會有大量的資
源浪費的現象，大機器且昂貴不易擴充。

![N|Solid](https://raw.githubusercontent.com/yushlee/spring-boot-restful/master/doc/img/monolith.png)

## Microservices 微服務架構
- 應用程式會拆分並且建立為獨立元件，並會以服務的形式執行個別應用程式程序 (業務功能或流程設計先行分割)。
這些服務使用輕量型 API (各個業務功能都獨立實作成一個能自主執行的個體服務)，透過定義良好的界面進行通訊。
服務係針對商業功能所建立，且每項服務皆可執行單一功能。因為每項服務皆獨立運作，
因此可以個別更新、部署和擴展，以滿足應用程式特定功能的需求。

![N|Solid](https://raw.githubusercontent.com/yushlee/spring-boot-restful/master/doc/img/Microservices.png)

## Spring boot RestController 實作
- @RestController
標注在 Controller 類別上，等同於 @Controller + @ResponseBody
- @RequestMapping
標注在 Controller 類別上，決定在此 Controller 內所有 API 共同的 prefixes URL
- @ApiOperation
標注在 Controller method 方法上，用以描述此 restful api 功能說明
- @GetMapping
標注在 Controller method 方法上，對應 HTTP GET 請求用於資料查詢
- @PostMapping
標注在 Controller method 方法上，對應 HTTP POST 請求用於資料新增
- @PutMapping
標注在 Controller method 方法上，對應 HTTP PUT 請求用於資料更新
- @PatchMapping
標注在 Controller method 方法上，對應 HTTP PATCH 請求用於欄位資料部份更新
- @DeleteMapping
標注在 Controller method 方法上，對應 HTTP DELETE 請求用於資料刪除
- @PathVariable
標注在 Controller method 方法參數上，可將URL網址列值動態帶入方法參數裡
- @RequestParam
標注在 Controller method 方法參數上，取得 HTTP 請求 Parameter 帶入方法參數
- @RequestBody
標注在 Controller method 方法參數上，支援前端參數值傳入 JSON 格式
Spring boot 自動轉換參數為 Java POJO 物件 
- @Validated
標注在 Controller method 方法參數上，用以驗証所傳入的物件參數欄位驗証
經常與 javax.validation.constraints.* 內的 annotation 類別使用搭配驗証功能
- ResponseEntity<T>
Spring boot 自動會將所要回傳的 POJO 物件轉為 JSON格式
因應不同情境回傳相對應的 HTTP status 代碼

## Spring Data JPA Transaction Manager
- 在 Server Layer 的方法上透過注釋 @Transactional 就可以進行交易事務的管理，統一在進入方法開始時取得建立資料庫連線，並且在最後方法結束時關閉資料庫連線
- Transactional rollbackFor
當執行 service 方法時若發生例外錯誤，交易事務管理將會自動進行交易資料倒回 (rollback) 的動作；Transactional 預設 rollback RuntimeException (unCheck Exception)，可再透過 rollbackFor 屬性指定要rollback的例外錯誤 ex：Exception (Check Exception)

## Transactional propagation (交易傳播行為)
- (1) REQUIRED (預設)：支援現在的交易，如果沒有的話就建立一個新的交易
![N|Solid](https://raw.githubusercontent.com/yushlee/spring-boot-restful/master/doc/img/REQUIRED.png)

- (2) REQUIRES_NEW：建立一個新的交易，如果現存一個交易的話就先暫停，並啟始一個新的交易
![N|Solid](https://raw.githubusercontent.com/yushlee/spring-boot-restful/master/doc/img/REQUIRES_NEW.png)

- (3) SUPPORTS：支援現在的交易，如果沒有的話就以非交易的方式執行
![N|Solid](https://raw.githubusercontent.com/yushlee/spring-boot-restful/master/doc/img/SUPPORTS.png)

- (4) NOT_SUPPORTED：指出不應在交易中進行，如果有的話就暫停現存的交易
![N|Solid](https://raw.githubusercontent.com/yushlee/spring-boot-restful/master/doc/img/NOT_SUPPORTED.png)

- (5) MANDATORY：方法必須在一個現存的交易中進行，否則丟出例外錯誤
No existing transaction found for transaction marked with propagation 'mandatory'
![N|Solid](https://raw.githubusercontent.com/yushlee/spring-boot-restful/master/doc/img/MANDATORY.png)

- (6) NEVER：指出不應在交易事務中進行否則丟出例外錯誤
Existing transaction found for transaction marked with propagation 'never'
![N|Solid](https://raw.githubusercontent.com/yushlee/spring-boot-restful/master/doc/img/NEVER.png)

- (7) NESTED：在一個巢狀的交易中進行 (支援交易儲存點 savepoint )，如果不是的話則同 REQUIRED
![N|Solid](https://raw.githubusercontent.com/yushlee/spring-boot-restful/master/doc/img/NESTED.png)

