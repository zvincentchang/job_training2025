package com.training.spring.aop;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.MethodParameter;
import org.springframework.http.MediaType;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;
import com.training.rest.model.StoreInfo;

@RestControllerAdvice
public class ControllerResponseAdvice implements ResponseBodyAdvice<Object> {
	
	private static Logger logger = LoggerFactory.getLogger(ControllerResponseAdvice.class);

	public boolean supports(MethodParameter returnType, Class converterType) {
		// true if beforeBodyWrite should be invoked; false otherwise
		return true;
	}

	public Object beforeBodyWrite(Object body, MethodParameter returnType, MediaType selectedContentType,
			Class selectedConverterType, ServerHttpRequest request, ServerHttpResponse response) {		
		if(body instanceof StoreInfo){
			// 測試 URL:http://localhost:8085/training/restfulController/createStoreInfo
			// 可在此處實作統一要對 Response物件要做的事
			logger.info("Method name:" + returnType.getMethod().getName());
			StoreInfo store = (StoreInfo)body;
			store.setSales(5700);
			logger.info(store.toString());
		}
		
		return body;
	}
}
