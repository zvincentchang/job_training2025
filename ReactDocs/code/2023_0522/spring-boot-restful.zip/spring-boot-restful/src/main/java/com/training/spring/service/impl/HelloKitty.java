package com.training.spring.service.impl;

import org.springframework.stereotype.Service;

import com.training.spring.service.HelloService;

@Service(value = "helloKitty")
public class HelloKitty implements HelloService {

	@Override
	public String sayHello() {
		return "HelloKitty";
	}

}
