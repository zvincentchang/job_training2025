package com.training.rest.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.training.rest.model.User;

@Repository
public interface UserDao extends JpaRepository<User, Long>{

	
}
