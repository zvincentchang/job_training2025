package com.training.spring.service.impl;

import org.springframework.stereotype.Service;

import com.training.spring.service.HelloService;

@Service(value = "helloSnoppy")
public class HelloSnoppy implements HelloService {

	@Override
	public String sayHello() {
		return "HelloSnoppy";
	}

}
