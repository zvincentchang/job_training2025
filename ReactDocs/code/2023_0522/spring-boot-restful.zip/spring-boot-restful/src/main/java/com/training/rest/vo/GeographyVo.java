package com.training.rest.vo;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import lombok.Data;

@Data
public class GeographyVo {
	
	@Min(value = 1, message = "Must be greater than 1")
	private Long geographyID;
	
	@NotNull
	@NotBlank
	@Pattern(regexp = "^(Ease)|(West)|(South)|(North)$", message = "regionName must be a (Ease)|(West)|(South)|(North)")
	private String regionName;
	
}
