package com.training.spring.aop;

import java.lang.reflect.Type;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.MethodParameter;
import org.springframework.http.HttpInputMessage;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.RequestBodyAdviceAdapter;
import com.training.rest.vo.StoreInfoVo;

// @RestControllerAdvice = @ControllerAdvice + @ResponseBody
// 「繼承」RequestBodyAdviceAdapter 比起「實作」RequestBodyAdvice 方便許多(可挑選要實作的方法)
@RestControllerAdvice
public class ControllerRequestAdvice extends RequestBodyAdviceAdapter {
	
	private static Logger logger = LoggerFactory.getLogger(ControllerRequestAdvice.class);

	public boolean supports(MethodParameter methodParameter, Type targetType,
			Class<? extends HttpMessageConverter<?>> converterType) {
		// whether this interceptor should be invoked or not
		return true;
	}
	
	public Object afterBodyRead(Object body, HttpInputMessage inputMessage, MethodParameter parameter,
			Type targetType, Class<? extends HttpMessageConverter<?>> converterType) {
		// @RestController method 須搭配使用  @RequestBody
		// 測試 URL:http://localhost:8085/training/restfulController/createStoreInfo		
		logger.info("Method name:" + parameter.getMethod().getName());
		if(body instanceof StoreInfoVo){
			// 可在此處實作統一要對 Request物件要做的事
			StoreInfoVo store = (StoreInfoVo)body;
			store.setSales(5600);
			logger.info(store.toString());
		}
		
		return body;
	}
}
