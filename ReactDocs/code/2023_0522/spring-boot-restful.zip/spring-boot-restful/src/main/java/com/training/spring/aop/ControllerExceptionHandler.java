package com.training.spring.aop;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import com.training.exception.BusinessException;

@RestControllerAdvice
public class ControllerExceptionHandler {	

	private static Logger errorLogger = LoggerFactory.getLogger("errorThrowable-log");
	
    @ExceptionHandler({BusinessException.class})
    public ResponseEntity<BusinessException> handleBusinessException(BusinessException ex) {
    	// 測試網址:http://localhost:8085/training/trainingController/controllerExceptionHandler?number=ABC
    	// 使用 @RestControllerAdvice搭配 @ExceptionHandler 統一處理應用程式中全部 Controller 所拋出的自訂義 Exception例外錯誤    	
    	errorLogger.error("error code:" + ex.getErrorCode());
    	errorLogger.error("error message:" + ex.getErrorMessage());
    	errorLogger.error(ex.getMessage(), ex);
    	
    	// 實務上經常會再包裝成自訂義物件後回傳
    	return ResponseEntity.ok(ex);
    }
	
}
