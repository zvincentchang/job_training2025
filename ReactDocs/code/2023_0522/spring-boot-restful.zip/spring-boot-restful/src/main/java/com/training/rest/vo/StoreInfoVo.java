package com.training.rest.vo;

import java.time.LocalDateTime;
import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import lombok.Data;

@Data
public class StoreInfoVo {
	
	@Min(value = 1, message = "Must be greater than 1")
	private long storeID;
	
	@NotNull
	@NotBlank
	@Pattern(regexp = "^[a-zA-Z]{5,20}$", message = "text [a-zA-Z] length between 5 ~ 20")
	private String storeName;
	
	@Min(value = 0, message = "Must be greater than 0")
	private long sales;
	
	// 若使用一般的java.util.date時間會誤差8小時 
	private LocalDateTime storeDate;	
	
	// 若欄位本身是個POJO物件則需要加上@Valid才會進行 內部物件欄位的驗証
	@Valid
	private GeographyVo geographyVo;
	
}
