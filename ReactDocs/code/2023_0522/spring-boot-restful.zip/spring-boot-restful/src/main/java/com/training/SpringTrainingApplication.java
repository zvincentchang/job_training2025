package com.training;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Scope;
import org.springframework.web.context.annotation.ApplicationScope;
import org.springframework.web.context.annotation.RequestScope;
import org.springframework.web.context.annotation.SessionScope;
import com.training.spring.vo.Student;
import com.training.spring.vo.User;

// http://localhost:8085/training/swagger-ui/index.html
@SpringBootApplication
public class SpringTrainingApplication {
	
	private static Logger logger = LoggerFactory.getLogger(SpringTrainingApplication.class);
	
	public static String SERVER_IP = null;
	
	public static void main(String[] args) {
		SpringApplication.run(SpringTrainingApplication.class, args);		
	}
	
	@Bean
	protected ServletContextListener listener() {
		return new ServletContextListener() {
			@Override
			public void contextInitialized(ServletContextEvent sce) {
				logger.info("ServletContext initialized");
				try {
					String hostname = InetAddress.getLocalHost().getHostName();
					InetAddress[] addresses = InetAddress.getAllByName(hostname);
					SERVER_IP = addresses[0].getHostAddress();
				} catch (UnknownHostException e) {
					logger.error(e.getMessage(), e);
				}
			}
			@Override
			public void contextDestroyed(ServletContextEvent sce) {
				logger.info("ServletContext destroyed");
			}
		};
	}

    @Bean(initMethod = "initMethod", destroyMethod = "destroyMethod")
//	@Scope(scopeName = ConfigurableBeanFactory.SCOPE_SINGLETON) // 單一實例(預設值)
//	@Scope(scopeName = ConfigurableBeanFactory.SCOPE_PROTOTYPE) // 多個實例
    public User user(){
        return new User();
    }
    
    @Bean
    @RequestScope
    public Student requestScopedBean(){
    	Student student = Student.builder()
    			.studentID(8).studentName("YuShangLee")
    			.grade("大三").build();
    	
        return student;
    }
    
    @Bean
    @SessionScope
    public Student sessionScopedBean(){
    	Student student = Student.builder()
    			.studentID(8).studentName("YuShangLee")
    			.grade("大三").build();
    	
        return student;
    }
    
    @Bean
    @ApplicationScope
    public Student applicationScopedBean() {
    	Student student = Student.builder()
    			.studentID(8).studentName("YuShangLee")
    			.grade("大三").build();
    	
        return student;
    }
    
    @Bean
    public Map<Integer, String> nameMap(){
        Map<Integer, String>  nameMap = new HashMap<>();
        nameMap.put(1, "John");
        nameMap.put(2, "Adam");
        nameMap.put(3, "Harry");
        return nameMap;
    }
    
    @Bean
    public List<String> nameList() {
        return Arrays.asList("John", "Adam", "Harry");
    }
    
}
