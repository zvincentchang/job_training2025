package com.training.rest.service;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.training.rest.dao.StoreInfoDao;
import com.training.rest.model.StoreInfo;

@Service
public class StoreInfoJpaService {
	
	private static Logger logger = LoggerFactory.getLogger(StoreInfoJpaService.class);
	
	@Autowired
	private StoreInfoDao storeInfoDao; 

	public List<StoreInfo> findAllStoreInfo(String userID){
		List<StoreInfo> storeInfos = storeInfoDao.findAll();
		storeInfos.forEach(s -> {
			try { Thread.sleep(2000); } catch (InterruptedException e) { }
			logger.info("userID("+ userID +"):" + s.toString());
		});
		
		return storeInfos;
	}
}
