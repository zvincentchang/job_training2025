package com.training.rest.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.training.rest.model.StoreInfo;

@Repository
public interface StoreInfoDao extends JpaRepository<StoreInfo, Long>{

	
}
