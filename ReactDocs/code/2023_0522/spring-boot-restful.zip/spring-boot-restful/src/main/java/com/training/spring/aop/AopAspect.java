package com.training.spring.aop;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import com.training.SpringTrainingApplication;
import com.training.spring.vo.User;

@Aspect
@Component
public class AopAspect {
	
	private static Logger logger = LoggerFactory.getLogger(AopAspect.class);
	
	private static Logger errorLogger = LoggerFactory.getLogger("errorThrowable-log");
	
	/*
	  @Pointcut路徑拆解說法
	  (* com.training.service.impl.AopServiceImpl.aopServiceMethod(..))
	  1. execution:在方法執行時觸發
	  2. *:回傳任意型別
	  3. com.training.service.impl:類別 package路徑
	  4. AopServiceImpl:要切入的"類別名稱"，可用*表示任意類別
	  5. aopServiceMethod:要切入的"方法名稱"，可用*表示任意方法
	  6. (..):任意參數
	*/
	@Pointcut(value = "execution(* com.training.spring.service.impl.AopServiceImpl.aopServiceMethodOne(..))")
	public void aopServiceMethodOne(){}

	@Pointcut(value = "execution(* com.training.spring.service.impl.AopServiceImpl.aopServiceMethodTwo(..))")
	public void aopServiceMethodTwo(){}
	
	/*
		執行時機:目標方法執行前
		使用情境:可以取得被執行Method「參數」
	*/
//	@Before("aopServiceMethodOne() && args(user)")
//	private void beforeAspect(JoinPoint joinPoint, User user) {
//		logger.info("AopAspect Before Start.....");
//		// 取得被AOP的服務方法"名稱"
//		String serviceMethodName = joinPoint.getSignature().getName();		
//		logger.info(serviceMethodName);
//		logger.info(user.toString());
//		user.setName("EricLee");
//		logger.info(user.toString());
//		logger.info("AopAspect Before End.....");
//	}
	
	/*
		執行時機:目標方法執行後
	*/
//	@After("aopServiceMethodOne()")
//	private void afterAspect(JoinPoint joinPoint) {
//		logger.info("AopAspect After Start.....");
//		// 取得被AOP的服務方法"名稱"
//		String serviceMethodName = joinPoint.getSignature().getName();
//		logger.info(serviceMethodName);	
//		logger.info("AopAspect After End.....");
//	}
	
	/*
		執行時機:目標方法執行後
		使用情境:可以取得被執行Method「目標方法的返回值」
	*/
//	@AfterReturning(value = "aopServiceMethodOne()", returning = "user")
//	private void afterReturningAspect(JoinPoint joinPoint, User user) {
//		logger.info("AopAspect AfterReturning Start.....");
//		// 取得被AOP的服務方法"名稱"
//		String serviceMethodName = joinPoint.getSignature().getName();
//		logger.info(serviceMethodName);
//		logger.info(user.toString());
//		user.setName("EricLee");
//		logger.info(user.toString());
//		logger.info("AopAspect AfterReturning End.....");
//	}
	
	/*
 		執行時機:執行於方法執行前/後
 		使用情境:可決定Target的方法是否執行、可以修改方法回傳結果 		
	 */
//	@Around("aopServiceMethodOne() || aopServiceMethodTwo()")
//	private Object aroundAspect(ProceedingJoinPoint joinPoint) throws Throwable {
//		logger.info("AopAspect Around Start.....");
//		Object obj = null;
//		try {			
//			System.out.println(SpringTrainingApplication.SERVER_IP);
//			// 取得被AOP的服務方法"名稱"
//			String serviceMethodName = joinPoint.getSignature().getName();
//			logger.info(serviceMethodName);
//			// 取得被AOP的服務方法"參數"
//			Object[] args = joinPoint.getArgs();
//			for(Object arg : args) {
//				logger.info(arg.toString());
//			}
//			obj = joinPoint.proceed();
//		} catch (Throwable e) {
//			// 統一 catch 所有例外錯誤並且集中至error log檔案			
//			errorLogger.error(e.getMessage(), e);
//			throw e;
//		}
//		logger.info("AopAspect Around End.....");
//		
//		return obj;
//	}
	
	/*
		執行時機:目標方法執行後
		使用情境:目標Method發生例外錯誤時
		Throw Advice的任務只是呼叫對應的方法，並不能在Throws Advice中將例外處理掉，在Throw Advice執行完畢後，
		原先的例外仍被傳播至應用程式之中，Throw Advice並不介入應用程式的例外處理，例外處理仍舊是應用程式本身所要負責的，
		如果想要在Throw Advice處理時中止應用程式的處理流程，作法是丟出其它的例外。
	*/
//	@AfterThrowing(value = "aopServiceMethodOne()", throwing="ex")  
//	public void afterThrowingAspect(JoinPoint joinPoint, Exception ex){  
//		logger.info("AopAspect AfterThrowing Start.....");
//		// 取得被AOP的服務方法"名稱"
//		String serviceMethodName = joinPoint.getSignature().getName();
//		logger.info(serviceMethodName);
//		logger.error(ex.getMessage());
//		logger.info("AopAspect AfterThrowing End.....");
//	}
	
}
