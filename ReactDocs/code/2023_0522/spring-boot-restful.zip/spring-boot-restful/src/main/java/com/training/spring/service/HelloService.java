package com.training.spring.service;

public interface HelloService {
	
	public String sayHello();
	
}
