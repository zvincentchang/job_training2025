package com.training.rest.service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.training.rest.dao.StoreInfoDao;
import com.training.rest.model.StoreInfo;
import com.training.rest.vo.StoreInfoVo;

@Service
public class StoreInfoService {
	
	@Autowired
	private StoreInfoDao storeInfoDao; 
		
	public List<StoreInfo> findAllStoreInfo(){
		
		return storeInfoDao.findAll();
	}
	
	public StoreInfo findStoreInfoByStoreID(long storeID) {
		
		return storeInfoDao.findById(storeID).orElse(null);
	}
	
	public StoreInfo createStoreInfo(StoreInfoVo storeInfoVo) {
		StoreInfo storeInfo = StoreInfo.builder()
				.storeID(storeInfoVo.getStoreID())
				.storeName(storeInfoVo.getStoreName())
				.storeDate(storeInfoVo.getStoreDate())
				.sales(storeInfoVo.getSales())
				.geographyID(storeInfoVo.getGeographyVo().getGeographyID())
				.regionName(storeInfoVo.getGeographyVo().getRegionName())
				.build();
		
		return storeInfoDao.save(storeInfo);
	}
	
	@Transactional
	public StoreInfo updateStoreInfo(StoreInfoVo storeInfoVo) {
		// 搭配使用 @Transactional 查詢載入的物件受到 PersistenceContext 的管理
		Optional<StoreInfo> optStoreInfo = storeInfoDao.findById(storeInfoVo.getStoreID());
		StoreInfo storeInfo = null;
		if(optStoreInfo.isPresent()) {
			storeInfo = optStoreInfo.get();
			storeInfo.setStoreName(storeInfoVo.getStoreName());
			storeInfo.setStoreDate(storeInfoVo.getStoreDate());
			storeInfo.setSales(storeInfoVo.getSales());
			storeInfo.setGeographyID(storeInfoVo.getGeographyVo().getGeographyID());
			storeInfo.setRegionName(storeInfoVo.getGeographyVo().getRegionName());
		}
//		storeInfoDao.save(storeInfo);
		
		return storeInfo;
	}	
	
	public void deleteStoreInfo(long storeID) {
		storeInfoDao.deleteById(storeID);
	}
	
}
