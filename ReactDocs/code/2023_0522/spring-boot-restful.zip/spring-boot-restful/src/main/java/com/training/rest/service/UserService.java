package com.training.rest.service;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.training.rest.dao.UserDao;
import com.training.rest.model.User;

@Service
public class UserService {
	
	@Autowired
	private UserDao userDao;
	
	public List<User> batchInsertUsers(int endChar) {
		List<User> users = new ArrayList<>();
		for(int i = 65 ; i < endChar ; i++) {
			User user = User.builder().userName((char) i).build();
			users.add(user);
		}
		
		// 透過 saveAll、deleteAll 達到批次新增、更新、刪除處理資料庫
		return userDao.saveAll(users);
	}
	
}
