package com.training.rest.model;

import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@SuperBuilder
@NoArgsConstructor
@Data
@ToString
@EqualsAndHashCode(of = {"storeID"})
@Entity
@Table(name = "STORE_INFORMATION")
public class StoreInfo {

	@Id
	@Column(name = "STORE_ID")
	private long storeID;
	
	@Column(name = "STORE_NAME")
	private String storeName;
	
	@Column(name = "SALES")
	private long sales;
	
	@Column(name = "STORE_DATE")
	private LocalDateTime storeDate;
	
	@Column(name = "GEOGRAPHY_ID")
	private Long geographyID;
	
	@Column(name = "REGION_NAME")
	private String regionName;
	
}
