package com.training.spring.controller;

import java.util.LinkedHashMap;
import java.util.Map;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.WebApplicationContext;
import com.training.exception.BusinessException;
import com.training.spring.service.HelloService;
import com.training.spring.service.impl.AopServiceImpl;
import com.training.spring.vo.Student;
import com.training.spring.vo.User;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/trainingController")
public class TrainingController {
	
	//	LoggerFactory透濄class名稱建立預設使用<root level="info">
	private static Logger logger = LoggerFactory.getLogger(TrainingController.class);
	
	@Autowired
	private User user;
	
	@Autowired
	private User user1;
	
	@Autowired
	private User user2;
	
	@Resource(name = "requestScopedBean")
	private Student requestStudent;
	
	@Resource(name = "sessionScopedBean")
	private Student sessionStudent;	
	
	@Resource(name = "applicationScopedBean")
	private Student applicationStudent;		
	
	@Autowired
	private AopServiceImpl aopService;
	
	// 操作使用共同的介面且注入不同實作
	@Autowired
	@Qualifier(value = "helloKitty")
	private HelloService helloKitty;
	
	// 操作使用共同的介面且注入不同實作
	@Autowired
	@Qualifier(value = "helloSnoppy")
	private HelloService helloSnoppy;
	
	@ApiOperation(value = "Spring boot Bean Lifecycle")
	@GetMapping(value = "/queryUserBean")
	public ResponseEntity<User> queryUserBean(){
		
		return ResponseEntity.ok(user);
	}
	
	@ApiOperation(value = "Spring boot Bean Scope (singleton、prototype)")
	@GetMapping(value = "/beanScopeSingletonAndPrototype")
	public ResponseEntity<Boolean> beanScopeSingletonAndPrototype(){
		// singleton:每一個注入都是相同個物件實例
		// prototype:每一個注入都是不同的物件實例
		
		return ResponseEntity.ok(user1 == user2);
	}
	
	@ApiOperation(value = "Spring boot Bean Scope Data Set (HttpRequest、HttpSession)")
	@PutMapping(value = "/beanScopeDataSet")
	public ResponseEntity<Map<String,String>> beanScopeDataSet(){
		
		// request:無法跨 HttpRequest之間存取
		requestStudent.setStudentID(9);
		requestStudent.setStudentName("Tony Stark");
		requestStudent.setGrade("碩一");
		
		// Session:可跨HttpRequest之間存取
		sessionStudent.setStudentID(9);
		sessionStudent.setStudentName("Tony Stark");
		sessionStudent.setGrade("碩一");
		
		// application:全域的 ServletContext不受到 Session timeout 影響
		applicationStudent.setStudentID(9);
		applicationStudent.setStudentName("Tony Stark");
		applicationStudent.setGrade("碩一");
				
		Map<String, String> userMap = new LinkedHashMap<>();
		userMap.put(WebApplicationContext.SCOPE_REQUEST, requestStudent.toString());
		userMap.put(WebApplicationContext.SCOPE_SESSION, sessionStudent.toString());
		userMap.put(WebApplicationContext.SCOPE_APPLICATION, applicationStudent.toString());
		
		return ResponseEntity.ok(userMap);
	}	
	
	@ApiOperation(value = "Spring boot Bean Scope Data Get (HttpRequest、HttpSession)")
	@GetMapping(value = "/beanScopeDataGet")
	public ResponseEntity<Map<String,String>> beanScopeDataGet(HttpServletRequest request){
		logger.info("session id:" + request.getSession().getId());
		Map<String, String> userMap = new LinkedHashMap<>();
		userMap.put(WebApplicationContext.SCOPE_REQUEST, requestStudent.toString());
		userMap.put(WebApplicationContext.SCOPE_SESSION, sessionStudent.toString());
		userMap.put(WebApplicationContext.SCOPE_APPLICATION, applicationStudent.toString());
		
		return ResponseEntity.ok(userMap);
	}	
	
	@ApiOperation(value = "Spring boot IOC (Inversion of Control)")
	@GetMapping(value = "/helloKitty")
	public ResponseEntity<String> helloKitty(){
		// 傳入不同的實作 HelloKitty
		return ResponseEntity.ok(serviceOperations(helloKitty));
	}	
	
	@ApiOperation(value = "Spring boot IOC (Inversion of Control)")
	@GetMapping(value = "/helloSnoppy")
	public ResponseEntity<String> helloSnoppy(){
		// 傳入不同的實作 HelloSnoppy
		return ResponseEntity.ok(serviceOperations(helloSnoppy));
	}
	
	private String serviceOperations(HelloService helloService) {
		// 由父元件介面操作而不依賴子元件實作
		return helloService.sayHello();
	}
	
	@ApiOperation(value = "Spring boot AOP (Aspect Oriented Programming)")
	@GetMapping(value = "/aopServiceMethodOne")
	public ResponseEntity<User> aopServiceMethodOne(){
		logger.debug("-----logger.level.debug-----");
		logger.info("-----logger.level.info-----");
		logger.warn("-----logger.level.warn-----");
		logger.error("-----logger.level.error-----");		
		
		return ResponseEntity.ok(aopService.aopServiceMethodOne(user));
	}
	
	@ApiOperation(value = "Spring boot AOP (Aspect Oriented Programming)")
	@GetMapping(value = "/aopServiceMethodTwo")
	public ResponseEntity<User> aopServiceMethodTwo(){
		
		return ResponseEntity.ok(aopService.aopServiceMethodTwo(user));
	}
	
	@ApiOperation(value = "Spring boot AOP @RestControllerAdvice ControllerExceptionHandler")
	@GetMapping(value = "/controllerExceptionHandler")
	public ResponseEntity<Integer> controllerExceptionHandler(@RequestParam String number){		
		int no = 0;
		try {
			no = Integer.parseInt(number);
		} catch(Exception ex) {
			BusinessException be = new BusinessException(ex);
			be.setErrorCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			be.setErrorMessage(ex.getMessage());		
			throw be;
		}
		
		return ResponseEntity.ok(no);
	}
	
}
