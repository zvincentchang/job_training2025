package com.training.spring.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.training.spring.vo.User;

@Service
public class AopServiceImpl {
	
	private static Logger logger = LoggerFactory.getLogger(AopServiceImpl.class);
	
	public User aopServiceMethodOne(User user) {
		logger.info("AopServiceImpl aopServiceMethodOne Start ...");
//		Integer.parseInt("ABC");
		logger.info("AopServiceImpl aopServiceMethodOne End ...");
		
		return user;
	}
	
	public User aopServiceMethodTwo(User user) {
		logger.info("AopServiceImpl aopServiceMethodTwo Start ...");
		logger.info("AopServiceImpl aopServiceMethodTwo End ...");
		
		return user;
	}
	
}
