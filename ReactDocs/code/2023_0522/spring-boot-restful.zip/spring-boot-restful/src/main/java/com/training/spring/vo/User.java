package com.training.spring.vo;

import java.util.List;
import java.util.Map;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import lombok.ToString;

@ToString
public class User implements InitializingBean, DisposableBean {
	
    private String name;
    
    private List<String> nameList;
    
    private Map<Integer, String> nameMap;
    
    public User() {
        System.out.println("调用Bean的方法(constructor)");
    }

	public String getName() {
        return name;
    }	
	
    public List<String> getNameList() {
		return nameList;
	}

	public Map<Integer, String> getNameMap() {
		return nameMap;
	}

	@Autowired
	public void setName(@Value("${springboot.bean.setter.name}") String name) {
		System.out.println("调用Bean的方法(setName)");
		this.name = name;
	}

    @Autowired
	public void setNameList(List<String> nameList) {
    	System.out.println("调用Bean的方法(setNameList)");
		this.nameList = nameList;
	}
    
    @Autowired
	public void setNameMap(Map<Integer, String> nameMap) {
    	System.out.println("调用Bean的方法(setNameMap)");
		this.nameMap = nameMap;
	}

	@PostConstruct
    public void postConstruct(){
        System.out.println("调用Bean的方法(@PostConstruct)");
    }
    
    // @Bean initMethod
    public void initMethod(){
        System.out.println("调用Bean的方法(@Bean initMethod)");
    }
    
    // InitializingBean 接口的方法 afterPropertiesSet
    @Override
    public void afterPropertiesSet() throws Exception {
        System.out.println("调用Bean的方法(InitializingBean afterPropertiesSet)");
    }
    
    @PreDestroy
    public void preDestroy(){
        System.out.println("调用Bean的方法(@PreDestroy)");
    }
    
    // DisposableBean 接口的方法 destroy
    @Override
    public void destroy() throws Exception {
        System.out.println("调用Bean的方法(DisposableBean destroy)");
    }
    
    // @Bean destroyMethod
    public void destroyMethod(){
        System.out.println("调用Bean的方法(@Bean destroyMethod)");
    }
    
}