package com.training.spring.vo;

import lombok.Builder;
import lombok.Data;
import lombok.ToString;

@Builder
@Data
@ToString
public class Student {
	
	private int studentID;
	
	private String studentName;
	
	private String grade;
}
