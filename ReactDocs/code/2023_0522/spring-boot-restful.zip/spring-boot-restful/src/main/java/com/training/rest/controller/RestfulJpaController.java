package com.training.rest.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.training.rest.model.StoreInfo;
import com.training.rest.service.StoreInfoJpaService;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/restfulJpaController")
public class RestfulJpaController {
	
	@Autowired
	private StoreInfoJpaService storeInfoJpaService;
	
	@ApiOperation(value = "Test Hikari Connection Pool")
	@GetMapping(value = "/testHikariConnectionPool")
	public ResponseEntity<List<StoreInfo>> testHikariConnectionPool(@RequestParam("userID") String userID) {
		List<StoreInfo> storeInfos = storeInfoJpaService.findAllStoreInfo(userID);
		
		return ResponseEntity.ok(storeInfos);
	}
	
}
