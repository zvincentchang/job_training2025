package com.training.rest.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.training.rest.model.StoreInfo;
import com.training.rest.model.User;
import com.training.rest.service.StoreInfoService;
import com.training.rest.service.UserService;
import com.training.rest.vo.StoreInfoVo;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/restfulController")
public class RestfulController {
	
	@Autowired
	private StoreInfoService storeInfoService;

	@Autowired
	private UserService userService;
	
//	@ApiOperation(value = "Restful GET: It reads a resource.")
	@ApiOperation(value = "Restful GET: 查詢所有商店資料")
	@GetMapping(value = "/findAllStoreInfo")
	public ResponseEntity<List<StoreInfo>> findAllStoreInfo() {
		List<StoreInfo> storeInfos = storeInfoService.findAllStoreInfo();
		
		return ResponseEntity.ok(storeInfos);
	}
	
	@ApiOperation(value = "Restful GET: It retrieves the detail of a resource @PathVariable.")
	@GetMapping(value = "/storeInfo/{storeID}")
	public ResponseEntity<StoreInfo> findStoreInfoByPathVariable(@PathVariable("storeID") long storeID) {
		StoreInfo storeInfo = storeInfoService.findStoreInfoByStoreID(storeID);
		
		return ResponseEntity.ok(storeInfo);
	}
	
	@ApiOperation(value = "Restful GET: It retrieves the detail of a resource. @RequestParam")
	@GetMapping(value = "/storeInfo")
	public ResponseEntity<StoreInfo> findStoreInfoByRequestParam(@RequestParam("storeID") long storeID) {
		StoreInfo storeInfo = storeInfoService.findStoreInfoByStoreID(storeID);
		
		return ResponseEntity.ok(storeInfo);
	}
	
	@ApiOperation(value = "Restful POST: It creates a new resource.")
	@PostMapping(value = "/createStoreInfo")
	public ResponseEntity<StoreInfo> createStoreInfo(@Validated @RequestBody StoreInfoVo storeInfoVo) {
		/* Input:範例
			{
			  "storeID": 10,
			  "storeName": "AppleStore",
			  "storeDate": "2021-11-10T05:42:15",
			  "sales": 5500,
			  "geographyVo": {
			    "geographyID": 3,
			    "regionName": "North"
			  }
			}
		 */
		StoreInfo storeInfo = storeInfoService.createStoreInfo(storeInfoVo);
		
		return ResponseEntity.ok(storeInfo);
	}
	
	@ApiOperation(value = "Restful PUT: It updates an existing resource.")
	@PutMapping(value = "/updateStoreInfo")
	public ResponseEntity<StoreInfo> updateStoreInfo(@Validated @RequestBody StoreInfoVo storeInfoVo) {
		/* Input:範例
			{
			  "storeID": 10,
			  "storeName": "AppleInc",
			  "storeDate": "2021-08-15T18:30:20",
			  "sales": 6000,
			  "geographyVo": {
			    "geographyID": 3,
			    "regionName": "North"
			  }
			}
		 */
		StoreInfo storeInfo = storeInfoService.updateStoreInfo(storeInfoVo);
		
		return ResponseEntity.ok(storeInfo);
	}
	
	@ApiOperation(value = "Restful DELETE: It deletes the resource.")
	@DeleteMapping(value = "/deleteStoreInfo")
	public ResponseEntity<Long> deleteStoreInfo(@RequestParam("storeID") long storeID) {
		storeInfoService.deleteStoreInfo(storeID);
		
		return ResponseEntity.ok(storeID);
	}
	
	@ApiOperation(value = "Restful POST: It Batch Inserts a resource.")
	@PostMapping(value = "/batchInsertUsers")
	public ResponseEntity<List<User>> batchInsertUsers(@RequestParam("endChar") int endChar) {		
		// 秒、毫、微、納
		// 1s 等於 1,000,000,000ns(納秒)		
		List<User> users = userService.batchInsertUsers(endChar);		
		
		return ResponseEntity.ok(users);
	}	
	
}
