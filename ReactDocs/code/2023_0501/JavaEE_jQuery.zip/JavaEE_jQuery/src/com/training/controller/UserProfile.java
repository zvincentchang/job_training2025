package com.training.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.sf.json.JSONObject;

public class UserProfile extends HttpServlet{
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		
		System.out.println(req.getParameter("userID"));
		
		// http://localhost:8085/JavaEE_jQuery/UserProfile
		JSONObject queryResult = new JSONObject();
		queryResult.put("name", "YuShangLee");
		queryResult.put("picture", "picture url");
		
		resp.setCharacterEncoding("UTF-8");
		resp.setContentType("application/json");
		PrintWriter out = resp.getWriter();
		out.println(queryResult);
		out.flush();
		out.close();
	}
	
}
