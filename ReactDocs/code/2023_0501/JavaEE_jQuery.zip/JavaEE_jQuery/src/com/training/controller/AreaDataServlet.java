package com.training.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.sf.json.JSONObject;

public class AreaDataServlet extends HttpServlet{

	private static Map<String, List<String>> areaDatas;
	
	@Override
	public void init() throws ServletException {
		super.init();
		areaDatas = new HashMap<String, List<String>>();
		// 基隆市
		List<String> keelungArea = new ArrayList<String>();
		keelungArea.add("仁愛區");
		keelungArea.add("安樂區");
		keelungArea.add("暖暖區");
		keelungArea.add("七堵區");
		areaDatas.put("keelung", keelungArea);
		// 臺北市
		List<String> taipeiArea = new ArrayList<String>();
		taipeiArea.add("中正區");
		taipeiArea.add("大同區");
		taipeiArea.add("中山區");
		taipeiArea.add("松山區");
		taipeiArea.add("信義區");
		areaDatas.put("taipei", taipeiArea);
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// http://localhost:8080/JavaEE_jQuery/areaDataServlet?area=taipei
		String area = req.getParameter("area");
		List<String> areaList = (List) areaDatas.get(area);
		JSONObject queryResult = new JSONObject();
		if(areaList != null){
			queryResult.put("queryStatus", true);
			queryResult.put("areaList", areaList);
		}else{
			queryResult.put("queryStatus", false);
			queryResult.put("queryMessage", "查無此縣市區域資料!");
		}		
		
		resp.setCharacterEncoding("UTF-8");
		resp.setContentType("application/json");
		PrintWriter out = resp.getWriter();
		out.println(queryResult);
		out.flush();
		out.close();
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
        Map<String, String[]> parameterMap = req.getParameterMap();
        Set<String> parameterKeys = parameterMap.keySet();
        for(String parameterKey : parameterKeys){
        	System.out.println("ParameterName:" + parameterKey);
        	String[] parameterValues = parameterMap.get(parameterKey);
        	for(String parameterValue : parameterValues){
        		System.out.println("ParameterValues:" + parameterValue);
        	}
        	System.out.println("------------------------");
        }
        
        JSONObject result = JSONObject.fromObject(parameterMap);
		resp.setCharacterEncoding("UTF-8");
		resp.setContentType("application/json");
		PrintWriter out = resp.getWriter();
		out.println(result);
		out.flush();
		out.close();
	}
}
