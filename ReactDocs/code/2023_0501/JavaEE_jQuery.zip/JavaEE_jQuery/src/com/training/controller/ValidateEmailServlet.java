package com.training.controller;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ValidateEmailServlet extends HttpServlet {
	
	private static Set<String> eMails;
	
	@Override
	public void init() throws ServletException {
		eMails = new HashSet<String>();
		eMails.add("love@yahoo.com.tw");
		eMails.add("tom@gmail.com");
		eMails.add("alen@hotmail.com");
		eMails.add("yushang@bt.com.tw");
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String customerEmail = req.getParameter("customerEmail");
		/*
 			The serverside response must be a JSON string that must be "true" for valid elements, 
 			and can be "false", undefined, or null for invalid elements
		 */
		
		boolean isExisted = eMails.contains(customerEmail);
		
		resp.getWriter().write(String.valueOf(!isExisted));
	}
	
}
