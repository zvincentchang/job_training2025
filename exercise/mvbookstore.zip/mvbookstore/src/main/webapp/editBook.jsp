<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Edit Book</title>
</head>
<body>
<form action="BookController" method="post">
	<input type="hidden" name="action" value="update">
	<input type="hidden" name="id" value="${book.id}">
	Book Name:<input type="text" name="bookname" value="${book.bookname}"><br/>
	Publisher:<input type="text" name="publisher" value="${book.publisher}"><br/>
	Author:<input type="text" name="author" value="${book.author}"><br/>
	Price:<input type="text" name="price" value="${book.price}"><br/>
	<input type="submit" value="Update">
</form>
</body>
</html>