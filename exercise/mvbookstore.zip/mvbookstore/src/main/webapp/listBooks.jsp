<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Book List</title>
</head>
<body>

<table border="1" width="90%" align="center">
    <tr><th>ID</th><th>書名</th><th>價格</th><th>作者</th><th>出版社</th><th>操作</th></tr>
       <c:forEach var="book"   items="${books}">
        <tr>
			<td>${book.id}</td>
			<td>${book.bookname}</td>
			<td>${book.price}</td>
			<td>${book.author}</td>
			<td>${book.publisher}</td>
            <td>
                <a href="BookController?action=edit&id=${book.id}">修改</a>
                <a href="BookController?action=delete&id=${book.id}">刪除</a>
            </td>
        </tr>
      </c:forEach> 
</table>

</body>
</html>