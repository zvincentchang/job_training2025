

import model.Book;
import model.BookDAO;
import java.util.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/BookController")
public class BookController extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private BookDAO bookDAO = new BookDAO();

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("add".equals(action)) {
            String bookname = request.getParameter("bookname");
            double price = Double.parseDouble(request.getParameter("price"));
            String author = request.getParameter("author");
            String publisher = request.getParameter("publisher");

            bookDAO.addBook(new Book(0, bookname, price, author, publisher));
        } else if ("delete".equals(action)) {
            int id = Integer.parseInt(request.getParameter("id"));
            bookDAO.deleteBook(id);
        }else  if ("update".equals(action)) {   
        	String id = request.getParameter("id");
            String bookname = request.getParameter("bookname");
            double price = Double.parseDouble(request.getParameter("price"));
            String author = request.getParameter("author");
            String publisher = request.getParameter("publisher");
            bookDAO.updateBook(new Book(Integer.parseInt(id), bookname, price, author, publisher));
        }

       
    	List<Book> books = bookDAO.getAllBooks();
    	request.setAttribute("books", books);
    	request.getRequestDispatcher("listBooks.jsp").forward(request, response);

    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	String action = request.getParameter("action");
    	if ("delete".equals(action)) {
            int id = Integer.parseInt(request.getParameter("id"));
            bookDAO.deleteBook(id);
        }
    	if ("edit".equals(action)) {
            int id = Integer.parseInt(request.getParameter("id"));
            Book book=bookDAO.getBookById(id);
            request.setAttribute("book", book);
            request.getRequestDispatcher("editBook.jsp").forward(request, response);
            return;
        }
    	List<Book> books = bookDAO.getAllBooks();
    	request.setAttribute("books", books);
    	request.getRequestDispatcher("listBooks.jsp").forward(request, response);
    }
}
