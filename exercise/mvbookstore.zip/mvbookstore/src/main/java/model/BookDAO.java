package model;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class BookDAO {
    private static final String FILE_NAME = "books.dat";
    private List<Book> bookList;

    public BookDAO() {
        bookList = loadBooks(); // 初始化時讀取檔案
    }

    // 讀取 `books.dat` 檔案
    private List<Book> loadBooks() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(FILE_NAME))) {
            return (List<Book>) ois.readObject();
        } catch (FileNotFoundException e) {
            return new ArrayList<>(); // 若檔案不存在，回傳空列表
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    // 儲存 `books.dat` 檔案
    private void saveBooks() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILE_NAME))) {
            oos.writeObject(bookList);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // 取得所有書籍
    public List<Book> getAllBooks() {
        return bookList;
    }

    // 新增書籍
    public void addBook(Book book) {
        book.setId(bookList.size() + 1); // 自動設定 ID
        bookList.add(book);
        saveBooks();
    }

    // 刪除書籍
    public void deleteBook(int id) {
        bookList.removeIf(book -> book.getId() == id);
        saveBooks();
    }
    
    // 修改書籍
    public void updateBook(Book book) {
		bookList.removeIf(b -> b.getId() == book.getId());
		bookList.add(book);
		saveBooks();
	}
    public Book getBookById(int id) {
		return bookList.stream().filter(book -> book.getId() == id).findFirst().orElse(null);
	}
}
