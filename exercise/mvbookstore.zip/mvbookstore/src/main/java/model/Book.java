package model;

import java.io.Serializable;
import java.util.Objects;

public class Book implements Serializable {
    private static final long serialVersionUID = 1L; // 確保版本一致

    private int id;
    private String bookname;
    private double price;
    private String author;
    private String publisher;

    public Book() {}

    public Book(int id, String bookname, double price, String author, String publisher) {
        this.id = id;
        this.bookname = bookname;
        this.price = price;
        this.author = author;
        this.publisher = publisher;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getBookname() { return bookname; }
    public void setBookname(String bookname) { this.bookname = bookname; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public String getAuthor() { return author; }
    public void setAuthor(String author) { this.author = author; }

    public String getPublisher() { return publisher; }
    public void setPublisher(String publisher) { this.publisher = publisher; }

    @Override
    public String toString() {
        return "Book [id=" + id + ", bookname=" + bookname + ", price=" + price +
                ", author=" + author + ", publisher=" + publisher + "]";
    }

	@Override
	public int hashCode() {
		return Objects.hash(author, bookname, id, price, publisher);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Book other = (Book) obj;
		return Objects.equals(author, other.author) && Objects.equals(bookname, other.bookname) && id == other.id
				&& Double.doubleToLongBits(price) == Double.doubleToLongBits(other.price)
				&& Objects.equals(publisher, other.publisher);
	}
    
}

